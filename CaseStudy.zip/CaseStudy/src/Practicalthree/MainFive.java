package Practicalthree;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class MainFive {

	public static void main(String[] args) {
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner scinput= new Scanner(System.in);
		System.out.print("Enter first date in dd/MM/yyyy format:");
		String mdate  = scinput.nextLine();
	
		LocalDate enteredDate = LocalDate.parse(mdate,formatter);
		
		System.out.println("Enter the warrantee period");
		System.out.println("Enter the number of months");
		int months= scinput.nextInt();
					scinput.nextLine();
		System.out.println("Enter the number of years");			
		int years= scinput.nextInt();
		scinput.nextLine();
		scinput.close();
	
		System.out.println("After adding Years: "+ enteredDate.plusYears(years).plusMonths(months));			
		
					
		
	}

}
