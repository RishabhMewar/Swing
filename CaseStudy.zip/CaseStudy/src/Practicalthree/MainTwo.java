package Practicalthree;

public class MainTwo {

	public static void main(String[] args) {

		
	}

}
