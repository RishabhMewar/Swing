package Practicalthree;
import java.lang.StringBuilder;
public class One 
{
	
	public StringBuilder strb; 
	public String str ="Second String";
	public String str1 = "helloworld";
	public StringBuilder strb1 = new StringBuilder();
	public String str3a= new String("aaddfvvddghtr");
	public StringBuilder str3b= new StringBuilder();
	/*public One 
	{
		
	}*/
	
	public One(StringBuilder strb) {
		
		this.strb = strb;
	}

	public void replace()
	{
		for(int i=0;i<str.length();i++)
		{
			if(i%2!=0)
			{
				str= str.substring(0,i-1) + "#" + str.substring(i,str.length()); 
			}
		}
	}

	public void upper()
	{
		char ch;
		for(int i=0;i<str1.length();i++)
		{
			ch = str1.charAt(i);
			if(i%2!=0)
			{
				strb1.append(String.valueOf(ch).toUpperCase());
			}
			else
			{
				strb1.append(String.valueOf(ch).toLowerCase());
			}
		}
		
	}
	public void dup()
	{
		for(int i=0;i<str3a.length();i++)
		{
			for(int j=0;j<str3b.length();j++)
			{
				if((str3a.charAt(i))!= (str3b.charAt(j)))
				{
						str3b=str3b.append(String.valueOf(str3a.charAt(i)));
				}
			}
		}
		
	}
	
	public void display()
	{
		System.out.println("First condition: "+strb);
		System.out.println("Second condition: "+str);
		System.out.println("Third condition: "+str3b);
		System.out.println("Forth condition: "+strb1);
	}
}
