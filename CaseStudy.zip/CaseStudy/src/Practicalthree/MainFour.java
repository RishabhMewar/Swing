package Practicalthree;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class MainFour {

	public static void main(String[] args) {

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner scinput= new Scanner(System.in);
		System.out.print("Enter first date in dd/MM/yyyy format:");
		String input  = scinput.nextLine();
		
		scinput.close();
		LocalDate enteredDate = LocalDate.parse(input,formatter);
		
		System.out.print("Enter second date in dd/MM/yyyy format:");
		String input1  = scinput.nextLine();
		
		LocalDate end = LocalDate.parse(input1,formatter);
		
		Period period = enteredDate.until(end);
		
		System.out.println("Days:"+ period.getDays());
		System.out.println("Months:"+period.getMonths());
		System.out.println("Years:"+ period.getYears());
	
	}

}
