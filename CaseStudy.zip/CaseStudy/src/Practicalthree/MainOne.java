package Practicalthree;

public class MainOne {

	public static void main(String[] args) {
		
		
		StringBuilder strb= new StringBuilder("Vishal");
		
		strb.append(" Tandel");
	//	strb.append(" AAZZ");
		One obj = new One(strb);
		obj.replace();
		obj.upper();
		obj.dup();
		obj.display();

	}

}
