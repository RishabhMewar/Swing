package Practicalthree;
import java.lang.StringBuilder;
public class Seven {
	
	
	public	String firstName="Vishal";
	public	String lastName=" Tandel";
	public StringBuffer strb = new StringBuffer("Full Name: ");
	Seven()
	{
		
	}
	public void getFullName()
	{
	/*	this.firstName=firstName;
		this.lastName=lastName;
	*/

	
	strb.append(firstName);
	strb.append(lastName);
	}
    void display()
	{
		System.out.println(strb);
	}

}
