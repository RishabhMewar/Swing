package Practicalthree;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class MainSix {

	public static void main(String[] args) {
		
		Scanner scinput = new Scanner(System.in);
		System.out.println("Enter the Zone id");
		System.out.println("Asia/Tokyo");
		System.out.println("Europe/Paris");
		System.out.println("America/NewYork");
		System.out.println("US/Pacific");
		System.out.println("Africa/Cairo");
		System.out.println("Australia/Sydney");
		
		ZonedDateTime currentTimeInTokya = ZonedDateTime.now(ZoneId.of("Asia/Tokyo"));
		ZonedDateTime currentTimeInParis = ZonedDateTime.now(ZoneId.of("Europe/Paris"));
		ZonedDateTime currentTimeInNewYork = ZonedDateTime.now(ZoneId.of("America/NewYork"));
		ZonedDateTime currentTimeInPacific = ZonedDateTime.now(ZoneId.of("US/Pacific"));
		ZonedDateTime currentTimeInCairo = ZonedDateTime.now(ZoneId.of("Africa/Cairo"));
		ZonedDateTime currentTimeInSydney = ZonedDateTime.now(ZoneId.of("Australia/Sydney"));
		System.out.println("Enter Zone Id");
		int d = scinput.nextInt();
				scinput.nextLine();
		switch(d)
		{
		case 1:
		System.out.println("Delhi:"+ currentTimeInTokya);
		break;
		case 2:
		System.out.println("Paris:"+ currentTimeInParis);
		break;
		case 3:
		System.out.println("New York:"+ currentTimeInNewYork);
		break;
		case 4:
		System.out.println("Pacific:"+ currentTimeInPacific);
		break;	
		case 5:
			System.out.println("Cairo:"+ currentTimeInCairo);
		break;	
		case 6:
			System.out.println("Sydney:"+ currentTimeInSydney);
		default:
		System.out.println("Enter correct Zone Id");
		}
	}

}
