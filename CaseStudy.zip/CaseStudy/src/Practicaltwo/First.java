package Practicaltwo;

public class First {
	
	String fname;
	String lname;
	char gender;
	int age;
	float weight;
	
	public First()
	{
		
	}
	
	public First(String fname, String lname, char gender, int age, float weight) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.gender = gender;
		this.age = age;
		this.weight = weight;
	}
	
	public void display()
	{
		System.out.println("First Name: "+fname);
		System.out.println("Last Name: "+lname);
		System.out.println("Gender: "+gender);
		System.out.println("Age: "+age);
		System.out.println("Weight: "+weight);
	}

}
