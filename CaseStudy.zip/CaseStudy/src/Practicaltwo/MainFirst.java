package Practicaltwo;

public class MainFirst {

	public static void main(String[] args) {
		
		First obj= new First();
		obj= new First("Rishabh","Mewar",'M',22,62.00f);
		obj.display();
		
	}

}
