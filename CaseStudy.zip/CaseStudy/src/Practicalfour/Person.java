package Practicalfour;

public class Person {

	public String str;
	public float age;
	
	Person()
	{
		
	}
	public Person(String str, float age) {
		super();
		this.str = str;
		this.age = age;
	}


	@Override
	public String toString() {
		return "Person [str=" + str + ", age=" + age + "]";
	}
	
	
}
