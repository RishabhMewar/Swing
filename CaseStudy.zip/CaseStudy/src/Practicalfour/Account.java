package Practicalfour;

public class Account {
	//Here static variable is used in both the class
	public static long counter=10000;
	public long accNum;
	public double balance;
	Person accHolder = new Person();
	public Account(double balance, Person accHolder) {
		super();
		this.accNum = counter++;
		this.balance = balance;
		this.accHolder = accHolder;
	}
	//Here we have to access the variable more than one time
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public void deposit(double dep)
	{
		balance=balance+dep;
	}
	public boolean withdraw(double wid)
	{
		if(balance>=500)
		{	
			balance=balance-wid;
			return true;
		}
		else
		{
			System.out.println("Your minimum balance should be 500rs");
			return false;
		}
		
	}
	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance
				+ ", accHolder=" + accHolder + "]";
	}

	
	
}
