package Practicalfour;

public class CurrentAccount extends Account {

	public CurrentAccount(double balance, Person accHolder) {
		super(balance, accHolder);
		// TODO Auto-generated constructor stub
	}

	public final int overdraft=40000;

	@Override
	public boolean withdraw(double wid) {
		if(balance <= overdraft)
		{	
			super.withdraw(wid);
			return true;
		}
		else
		{
			return false;
		}
	
	}
	
	
}
