package Practicalfour;

public class SavingAccount extends Account {
	
	public SavingAccount(double balance, Person accHolder) {
		super(balance, accHolder);
		
	}

	public final int minibal=500;

	@Override
	public boolean withdraw(double wid) {
		// TODO Auto-generated method stub
		if(balance >=minibal)
		{	
			super.withdraw(wid);
			return true;
		}
		else
		{	
			return false;
		}
	}

}
