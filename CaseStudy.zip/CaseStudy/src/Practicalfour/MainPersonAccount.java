package Practicalfour;

public class MainPersonAccount {

	public static void main(String[] args) {

		Person p1 = new Person("smith",25);
		Person p2 = new Person("Kathy",30);
		
		Account a1 = new Account(2000,p1);
		Account a2 = new Account(3000,p2);
		System.out.println("Smith balance: " + a1.getBalance());
		System.out.println("Kathy balance: " + a2.getBalance());
		
		System.out.println("Deposit");
		a1.deposit(2000);
		
		
		
		System.out.println("Withdraw");
		a2.withdraw(2000);
		System.out.println("Updated Balance");
		System.out.println("Smith balance: " + a1.getBalance());
		System.out.println("Kathy balance: " + a2.getBalance());
		String s1 = a1.toString();
		String s2 = a2.toString();
		
		System.out.println(s1);
		System.out.println(s2);
	}

}
