package com.capgemini.a1;

import java.util.Scanner;

public class SecondClass 
{
	int number;
	
	public SecondClass()
	{
		
	}
	
	public SecondClass(int number)
	{
		this.number=number;
	}
	
	public void display()
	{
		if(number>0)
			System.out.println("Number is positive");
		else
			System.out.println("Number is negative");
	}
}
