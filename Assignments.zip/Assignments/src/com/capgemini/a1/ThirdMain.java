package com.capgemini.a1;

import java.util.Scanner;

import Practicaltwo.Gender;

public class ThirdMain 
{
	public static void main(String[] args) 
	{
		char gen;
		Scanner sc = new Scanner(System.in);
		
		
		System.out.println("Enter the first Name: ");
		String firstName= sc.nextLine();
		
		System.out.println("Enter the last Name: ");
		String lirstName= sc.nextLine();
		
		System.out.println("Enter the gender: ");
		int gender= sc.nextInt();
		             sc.nextLine();
		
		switch(gender)
		{
			case 0:
				gen = gender.M;
				break;
			case 1:
				gen = gender.F;
				break;
			
			default:
				System.out.println("Invalid Gender");
				break;
		
		}

	}

}
