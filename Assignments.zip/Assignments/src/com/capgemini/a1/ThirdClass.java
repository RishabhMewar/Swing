package com.capgemini.a1;

public class ThirdClass 
{
	public String firstName;
	public String lastName;
	public char Gender;
	
	public void ThirdClass()
	{
		
	}
	
	public ThirdClass(String fname, String lname, String phoneno, char gender )
	{
		this.firstName= fname;
		this.lastName= lname;
		this.Gender= gender;
	}
	
	public void display()
	{
		System.out.println("Person Details: ");
		System.out.println("_________________");
		System.out.println("First Name: "+ firstName);
		System.out.println("Last Name: "+ lastName);
		System.out.println("Gender: "+ Gender);
	}

}
