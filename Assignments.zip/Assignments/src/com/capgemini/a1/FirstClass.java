package com.capgemini.a1;

public class FirstClass 
{
	String FirstName;
	String LastName;
	char Gender;
	int Age;
	double Weight;
	
	public void FirstClass()
	{
		
	}
	
	public void FirstClass(String FirstName, String LastName, char Gender, int Age, double Weight)
	{
		this.FirstName= FirstName;
		this.LastName= LastName;
		this.Gender= Gender;
		this.Age= Age;
		this.Weight= Weight;
	}
	
	void show()
	{
		System.out.println("First Name: " + FirstName);
		System.out.println("------------------");
		System.out.println("Last Name: " + LastName);
		System.out.println("Gender: " + Gender);
		System.out.println("Age: " + Age);
		System.out.println("Weight: " + Weight);
	}
	
	

}
