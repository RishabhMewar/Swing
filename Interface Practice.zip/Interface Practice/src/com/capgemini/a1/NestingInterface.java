package com.capgemini.a1;

public interface NestingInterface 
{
	void meth1();
	void meth2();
}
