package com.capgemini.a1;

public interface NestingInterface2 extends NestingInterface
{
		void meth3();
}
