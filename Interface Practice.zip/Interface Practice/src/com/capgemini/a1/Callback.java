package com.capgemini.a1;

public interface Callback 
{
	void callback(int param);
}


