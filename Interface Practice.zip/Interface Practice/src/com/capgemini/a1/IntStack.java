package com.capgemini.a1;

public interface IntStack 
{
	void push(int item); // store an item
	int pop(); // retrieve an item
}


