package com.capgemini.a1;

public class TestInterface2 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Callback c = new Client();
		AnotherClient ob = new AnotherClient();
		c.callback(42);
		c = ob; // c now refers to AnotherClient object
		c.callback(42);
	}
}
