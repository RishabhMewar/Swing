package com.capgemini.cab.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import com.capgemini.cab.exception.CabRequestException;


public class DBUtil {

	private static Connection conn=null;
	public static Connection getConnection()throws CabRequestException{
		
		if(conn==null){
			try {
				FileInputStream fin = new FileInputStream("resource/JDBC.properties");
				Properties props=new Properties();
				props.load(fin);
				String driver = props.getProperty("db.driver");
				String url = props.getProperty("db.url");
				String user = props.getProperty("db.user");
				String pass = props.getProperty("db.pass");
				
				Class.forName(driver);
				
				conn = DriverManager.getConnection(url,user,pass);
			} catch (FileNotFoundException e) {
				throw new CabRequestException("Property file not found.."+e.getMessage());
			} catch (ClassNotFoundException e) {
				throw new CabRequestException("Driver class not found.."+e.getMessage());
			} catch (IOException e) {
				throw new CabRequestException("Problem in reading property.."+e.getMessage());
			} catch (SQLException e) {
				throw new CabRequestException("Problem in obtaining connection.."+e.getMessage());
			}
		}
		return conn;
	}

}
