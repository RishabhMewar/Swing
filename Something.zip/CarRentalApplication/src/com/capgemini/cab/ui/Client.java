package com.capgemini.cab.ui;


import java.time.LocalDate;



import java.util.HashMap;
import java.util.Scanner;

import com.capgemini.cab.bean.CabRequest;
import com.capgemini.cab.exception.CabRequestException;
import com.capgemini.cab.service.CabService;
import com.capgemini.cab.service.ICabService;



public class Client {

public static void main(String [] args) {
		
		Scanner sc=new Scanner(System.in);
		ICabService cser=new CabService();
		
		do{	//Printing menu
			System.out.println("Menu");
			System.out.println("1. Raise cab request");
			System.out.println("2. View cab request status");
			System.out.println("3. Exit");
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
			
			switch(choice){
				case 1:
					
					System.out.println("Enter customer name:");
					String customerName=sc.next();
					System.out.println("Enter phone number:");
					String phoneNumber=sc.next();
					LocalDate dateOfRequest=LocalDate.now();
					System.out.println("Enter pincode:");
					String pinCode=sc.next();
					System.out.println("Enter pickup address:");
					String addressOfPickup=sc.next();
					
					
				
					CabRequest cabRequest=new CabRequest();
					
					cabRequest.setCustomerName(customerName);
					cabRequest.setPhoneNumber(phoneNumber);
					cabRequest.setDateOfRequest(dateOfRequest);
					cabRequest.setPinCode(pinCode);
					cabRequest.setCabNumber(getCabNum(pinCode));
					
					cabRequest.setAddressOfPickup(addressOfPickup);
					cabRequest.setRequestStatus((getCabNum(pinCode)!=null)?"Accepted":"Not Accepted");
					
					try {
						if (cser.validateCabRequest(cabRequest)) {
							int rid = cser.addCabRequestDetails(cabRequest);
							System.out
									.println("Your cab request has been succesfully registered, yourrequest id is  :"
											+ rid);
						}
					} catch (CabRequestException e) {
						System.out.println(e.getMessage());
					}
					break;
				
				case 2:
					System.out.println("Enter cab request id to view status :");
					int rid=sc.nextInt();
					
				try {
					CabRequest cabRequest1=cser.getRequestDetails(rid);
					System.out.println("Name of the customer:	"+cabRequest1.getCustomerName());
					System.out.println("Request Status:    "+cabRequest1.getRequestStatus());
					System.out.println("Cab number:    "+cabRequest1.getCabNumber());
					System.out.println("Pickup Address:    "+cabRequest1.getAddressOfPickup());
				} catch (CabRequestException e) {
					System.out.println(e.getMessage());
				}
				break;
				
				
				case 3:System.exit(0);	
					
			}
			//sc.close();
		}while(true);
	}

	private static String getCabNum(String key){
		//HashMap to return car number
		HashMap<String, String> myMap=new HashMap<>();
		myMap.put("400096","MH VS 2345");
		myMap.put("411026","MH VS 34567");
		myMap.put("411013","MH AN 97886");
		myMap.put("560066","MH AS 875");
		myMap.put("382009","MH KN 9856");
		myMap.put("400708","MH TF 8956");
		
		return myMap.get(key);
		
		
	}
}
