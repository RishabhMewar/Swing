package com.capgemini.cab.dao;

import com.capgemini.cab.bean.CabRequest;
import com.capgemini.cab.exception.CabRequestException;

public interface ICabRequestDao {
	
	int addCabrequestDetails (CabRequest cabRequest) throws CabRequestException;
	CabRequest getRequestDetails(int requestId) throws CabRequestException;

}
