package com.capgemini.cab.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.capgemini.cab.bean.CabRequest;
import com.capgemini.cab.exception.CabRequestException;
import com.capgemini.cab.util.DBUtil;



public class CabRequestDao implements ICabRequestDao {

	
	Connection conn;
	Logger logger;
	
	private int generateRequestId() throws CabRequestException{
		int rid=0;
		String sql="SELECT seq_request_id.NEXTVAL FROM DUAL";
		conn = DBUtil.getConnection();
		
		try {
			Statement st =conn.createStatement();
			ResultSet rst =st.executeQuery(sql);
			rst.next();
			rid=rst.getInt(1);
		} catch (SQLException e) {
			throw new CabRequestException("Problem in generating request id.."+e.getMessage());
		}
		return rid;
	}
	@Override
	public int addCabrequestDetails(CabRequest cabRequest)
			throws CabRequestException {
		
		cabRequest.setRequestId(generateRequestId());
		String sql="INSERT INTO cab_request  VALUES(?,?,?,?,?,?,?,?)";
		conn=DBUtil.getConnection();
		
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, cabRequest.getRequestId());
			pst.setString(2, cabRequest.getCustomerName());
			pst.setString(3, cabRequest.getPhoneNumber());
			pst.setDate(4, Date.valueOf(cabRequest.getDateOfRequest()));
			pst.setString(5, cabRequest.getRequestStatus());
			pst.setString(6, cabRequest.getCabNumber());
			pst.setString(7, cabRequest.getAddressOfPickup());
			pst.setString(8, cabRequest.getPinCode());
			
			pst.executeUpdate(); //executing sql update statement
			//logger.debug(cabRequest.getRequestId()+"record inserted...");
		} catch (SQLException e) {
			//logger.error("Problem in inserting cab request details.."+e.getMessage());
			throw new CabRequestException("Problem in inserting cab request details.."+e.getMessage());
		}
		return cabRequest.getRequestId();
	}

	@Override
	public CabRequest getRequestDetails(int requestId)
			throws CabRequestException {
		String sql = "SELECT customer_name, request_status, cab_number, address_of_pickup FROM cab_request WHERE request_id=?";
		CabRequest crequest = null;
		conn = DBUtil.getConnection();
		
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, requestId);
			ResultSet rst = pst.executeQuery(); // executing sql query
			if(rst.next()){
				crequest=new CabRequest();
				crequest.setCustomerName(rst.getString("customer_name"));
				crequest.setRequestStatus(rst.getString("request_status"));
				crequest.setCabNumber(rst.getString("cab_number"));
				crequest.setAddressOfPickup(rst.getString("address_of_pickup"));
				
			}
			//logger.info(crequest.getRequestId()+"record details found...");
		} catch (SQLException e) {
			throw new CabRequestException("Problem in fetching cab request data.."+e.getMessage());
		}
		
		return crequest;
	}

}
