package com.capgemini.cab.bean;

import java.time.LocalDate;


public class CabRequest {
	
	private int requestId;
	private String customerName;
	private String phoneNumber;
	private LocalDate dateOfRequest;
	private String requestStatus;
	private String cabNumber;
	private String addressOfPickup;
	private String pinCode;
	public int getRequestId() {
		return requestId;
	}
	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public LocalDate getDateOfRequest() {
		return dateOfRequest;
	}
	public void setDateOfRequest(LocalDate dateOfRequest) {
		this.dateOfRequest = dateOfRequest;
	}
	public String getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}
	public String getCabNumber() {
		return cabNumber;
	}
	public void setCabNumber(String cabNumber) {
		this.cabNumber = cabNumber;
	}
	public String getAddressOfPickup() {
		return addressOfPickup;
	}
	public void setAddressOfPickup(String addressOfPickup) {
		this.addressOfPickup = addressOfPickup;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public CabRequest(int requestId, String customerName, String phoneNumber,
			LocalDate dateOfRequest, String requestStatus, String cabNumber,
			String addressOfPickup, String pinCode) {
		
		this.requestId = requestId;
		this.customerName = customerName;
		this.phoneNumber = phoneNumber;
		this.dateOfRequest = dateOfRequest;
		this.requestStatus = requestStatus;
		this.cabNumber = cabNumber;
		this.addressOfPickup = addressOfPickup;
		this.pinCode = pinCode;
	}
	@Override
	public String toString() {
		return "CabRequest [requestId=" + requestId + ", customerName="
				+ customerName + ", phoneNumber=" + phoneNumber
				+ ", dateOfRequest=" + dateOfRequest + ", requestStatus="
				+ requestStatus + ", cabNumber=" + cabNumber
				+ ", addressOfPickup=" + addressOfPickup + ", pinCode="
				+ pinCode + "]";
	}
	
	public CabRequest(){}
}
