package com.capgemini.cab.logger;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


public class CabRequestLogger {
	static Logger logger;
	public static Logger getLogger() {
		if(logger==null){
			logger=Logger.getLogger("CourseLogger");
			PropertyConfigurator.configure("resource/log4j.properties");
			
		}
		return logger;
	}
}