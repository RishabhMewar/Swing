package com.capgemini.cab.service;

import com.capgemini.cab.bean.CabRequest;
import com.capgemini.cab.dao.CabRequestDao;
import com.capgemini.cab.dao.ICabRequestDao;
import com.capgemini.cab.exception.CabRequestException;


public class CabService implements ICabService {
	
	ICabRequestDao icrdao= new CabRequestDao();

	@Override
	public int addCabRequestDetails(CabRequest cabRequest)
			throws CabRequestException {
		return icrdao.addCabrequestDetails(cabRequest);
	}

	@Override
	public CabRequest getRequestDetails(int requestId)
			throws CabRequestException {
		return icrdao.getRequestDetails(requestId);
	}

	@Override
	public boolean validateCabRequest(CabRequest cabRequest)
			throws CabRequestException {
		if(!cabRequest.getCustomerName().matches("[A-Z][a-z]{2,15}")){
			throw new CabRequestException("Customer name should start with Capital and between 2 to 15 characers"); 
		}
		if(!cabRequest.getPhoneNumber().matches("[9|8|7][0-9]{9}")){
			throw new CabRequestException("Phone number must start with 9 or 8 or 7 and of maximum 10 digits");
			
		}
		
		if(!cabRequest.getPinCode().matches("[0-9]{6}")){
			throw new CabRequestException("Pin code must be a digit and have only 6 digits");
			
		}
		
		return true;
	}

}
