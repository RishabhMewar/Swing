package com.capgemini.cab.service;

import com.capgemini.cab.bean.CabRequest;
import com.capgemini.cab.exception.CabRequestException;


public interface ICabService {
	
	int addCabRequestDetails(CabRequest cabRequest) throws CabRequestException;
	CabRequest getRequestDetails(int requestId) throws CabRequestException;
	public boolean validateCabRequest(CabRequest cabRequest)throws CabRequestException;

}
