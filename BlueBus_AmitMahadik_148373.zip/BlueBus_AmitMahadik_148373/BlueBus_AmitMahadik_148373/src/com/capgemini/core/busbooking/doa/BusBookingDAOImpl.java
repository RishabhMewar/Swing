package com.capgemini.core.busbooking.doa;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.core.busbooking.dto.BookingDetails;
import com.capgemini.core.busbooking.dto.BusSchedule;
import com.capgemini.core.busbooking.exception.BusBookingException;
import com.capgemini.core.busbooking.util.DBUtil;

public class BusBookingDAOImpl implements IBusBookingDAO {

	static Logger myLogger =
			Logger.getLogger(BusBookingDAOImpl.class.getName());
	
	/*
	 * Author: Amit Mahadik
	 * Emp ID: 343843	
	 * Date: 25th Oct 2017
	 * Description: Get Bus Schedule from Database
	 */
	
	@Override
	public List<BusSchedule> getBusSchedule() throws BusBookingException {

		myLogger.info("trying to fetch bus schedule");
		
		List<BusSchedule> busSchedule = null;

		try(Connection con = DBUtil.getConnection()) 
		{
			Statement stm = con.createStatement();
			ResultSet res = stm.executeQuery("select * from BusSchedule");

			busSchedule = new ArrayList<BusSchedule>();

			while( res.next() )
			{
				BusSchedule currentBus = new BusSchedule();

				currentBus.setBusId( res.getInt(1) );
				currentBus.setName( res.getString(2) );
				currentBus.setStartLocation( res.getString(3) );
				currentBus.setEndLocation( res.getString(4) );
				currentBus.setTiming( res.getString(5) );
				currentBus.setNoOfAvailableSeats( res.getInt(6) );

				busSchedule.add(currentBus);
			}

			if( busSchedule.isEmpty() )
				throw new Exception("No schedule to display");
		} 
		catch (Exception e) 
		{
//			e.printStackTrace(); //need to remove before submission
			myLogger.error(e.getMessage());
			throw new BusBookingException(e.getMessage());
		}

		return busSchedule;
	}

	/*
	 * Author: Amit Mahadik
	 * Emp ID: 343843	
	 * Date: 25th Oct 2017
	 * Description: Insert bOoking details into database table BookingDetails  
	 */
	
	@Override
	public int bookABus(BookingDetails bookingDetails) throws BusBookingException {

		myLogger.info("trying to Book A buS");
		
		int bookingId = 0;

		try(Connection con = DBUtil.getConnection()) 
		{
			try
			{

				//start transaction
				con.setAutoCommit( false );	

				//checking if requested seats are available of the selected bus

				PreparedStatement pstm = con.prepareStatement(
						"select AvailableSeats from BusSchedule where BusId=?");

				pstm.setInt(1, bookingDetails.getBusId());

				ResultSet res = pstm.executeQuery();

				if( res.next() == false )
					throw new Exception("BusId is invalid");

				int availableNoOfSeats = res.getInt(1);

				if( availableNoOfSeats == 0 )
					throw new Exception("We are Sorry, there are no more seats available on the selected bus, please selected another bus.");

				if(availableNoOfSeats < bookingDetails.getNoOfSeats() )
					throw new Exception("We are Sorry, the number of seats you request are not available on the selected bus");

				//Reserve the Desired number of seats

				PreparedStatement pstm2 = con.prepareStatement(
						"update BusSchedule set AvailableSeats=? where BusId=?");

				pstm2.setInt(1, availableNoOfSeats - bookingDetails.getNoOfSeats() );
				pstm2.setInt(2, bookingDetails.getBusId() );

				pstm2.execute();

				//Confirm Booking
				//a) Generate Booking ID
				Statement stm = con.createStatement();
				ResultSet res1 = stm.executeQuery("select bus_id_seq.nextVal from dual");

				if( res1.next() == false)
					throw new Exception("Failed to generate booking id");

				bookingId = res1.getInt(1);

				//b) Insert booking details

				PreparedStatement pstm3 = con.prepareStatement(
						"insert into BookingDetails values(?,?,?,?)");

				pstm3.setInt(1, bookingId );
				pstm3.setString(2, bookingDetails.getCustomerName() );
				pstm3.setInt(3, bookingDetails.getNoOfSeats() );
				pstm3.setInt(4, bookingDetails.getBusId() );

				pstm3.execute();

				con.commit(); //End of Transaction : Transaction was Successful
			}
			catch(Exception e)
			{
				con.rollback();
				throw new Exception(e);
			}
		} 
		catch (Exception e) 
		{
//			e.printStackTrace(); //need to remove this before submission
			myLogger.error(e.getMessage());
			throw new BusBookingException(e.getMessage());
		}

		return bookingId;
	}

}












