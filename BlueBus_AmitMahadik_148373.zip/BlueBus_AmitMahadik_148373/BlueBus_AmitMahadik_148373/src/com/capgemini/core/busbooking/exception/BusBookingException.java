package com.capgemini.core.busbooking.exception;

public class BusBookingException extends Exception 
{
	public BusBookingException() {
		super();
		
	}

	public BusBookingException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public BusBookingException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public BusBookingException(String message) {
		super(message);
		
	}

	public BusBookingException(Throwable cause) {
		super(cause);
		
	}
}
