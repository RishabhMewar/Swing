package com.capgemini.core.busbooking.util;

public class ValidationUtil 
{
	public static boolean isBusIdInvalid( int busId )
	{
		return busId <= 0 ? true : false; 
	}
	
	public static boolean isCustomerNameInvalid( String name )
	{
		if( name != null && name.trim().length() > 3 )
			return false;
		
		return true;
	}
	
	public static boolean isNoOfRequestedSeatsInvalid( int noOfSeats)
	{
		return noOfSeats <= 0 ? true : false;
	}
}
