package com.capgemini.core.busbooking.dto;

public class BookingDetails 
{
	private int id;
	private String customerName;
	private int noOfSeats;
	private int busId;
		
	public BookingDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public BookingDetails(String customerName, int noOfSeats, int busId) {
		super();
		this.customerName = customerName;
		this.noOfSeats = noOfSeats;
		this.busId = busId;
	}

	public BookingDetails(int id, String customerName, int noOfSeats, int busId) {
		super();
		this.id = id;
		this.customerName = customerName;
		this.noOfSeats = noOfSeats;
		this.busId = busId;
	}
	@Override
	public String toString() {
		return "BookingDetails [id=" + id + ", customerName=" + customerName + ", noOfSeats=" + noOfSeats + ", busId="
				+ busId + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getNoOfSeats() {
		return noOfSeats;
	}
	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}
	public int getBusId() {
		return busId;
	}
	public void setBusId(int busId) {
		this.busId = busId;
	}
	
	
}
