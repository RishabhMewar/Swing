package com.capgemini.tcc.exception;

public class invalidInput extends Exception {
	public invalidInput(String msg){
		super(msg);
	}

}
