package com.bvk.client;

import java.util.Scanner;

import com.bvk.entity.AddArray;
import com.bvk.exception.EmptyArrayException;

public class ClientLambdaException {

	public static void main(String[] args) {
		double numbers[] = null;
		double sum = 0.0;
		int size = 0;
		//AddArrayImpl addArrayImpl = new AddArrayImpl();
		
		//AddArray addArray = addArrayImpl;
		
		AddArray addArray = (n)->{
			double answer = 0.0;
			
			if(n.length == 0){
				throw new EmptyArrayException("No data provided.");
			}
			for (double number : n) {
				answer += number;
			}
			return answer;
		};
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter size of the array: ");
		size = scInput.nextInt();
			   scInput.nextLine();
			   
		numbers = new double[size];
		
		for(int i = 0 ; i < numbers.length ; i++){
			System.out.print("Enter an element: ");
			numbers[i] = scInput.nextDouble();
			   			 scInput.nextLine();
		}
		try{
			sum = addArray.sumArray(numbers);
			System.out.println("Sum of elements: " + sum);
		}catch(EmptyArrayException eae){
			System.out.println(eae.getMessage());
		}finally{
			scInput.close();
		}
	}
}