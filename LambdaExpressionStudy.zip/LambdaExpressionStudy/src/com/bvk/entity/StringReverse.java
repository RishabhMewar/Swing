package com.bvk.entity;

public class StringReverse implements GenericReverse<String> {

	@Override
	public String reverse(String t) {
		StringBuffer sbf = new StringBuffer(t);
		sbf.reverse();
		t = new String(sbf);
		
		return t;
	}

}
