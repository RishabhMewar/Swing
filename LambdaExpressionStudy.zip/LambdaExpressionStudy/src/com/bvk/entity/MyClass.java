package com.bvk.entity;

public class MyClass {
	private int value;
	
	public MyClass(){
		
	}
	
	public MyClass(int value){
		this.value = value;
	}

	public int getValue() {
		return value;
	}
}