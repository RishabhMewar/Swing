package code;

public class RaceCondition {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		TobeSync tbs = new TobeSync();
		
		Thread t1 = new Thread(new SyncThread(tbs,"World"));
		Thread t2 = new Thread(new SyncThread(tbs,"Hello"));
		
		t1.start();
		t2.start();
	}
}