package code;

public class TobeSync {
		public synchronized void output(String str){
//			synchronized(this){
			System.out.print("[");
			
			try{
				Thread.sleep(500);
			}catch(InterruptedException ie){
				System.out.println("Got Interrupted!!");
			}
			System.out.println(str+"]");
//		}
		}
		
		public synchronized void show(){
			
		}
		
		public void display(){
			
		}
		
		public static synchronized void disp(){
			
		}
}