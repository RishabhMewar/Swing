package code;

public class Q1 {
	int n;
	boolean valueset = false;

	synchronized int get() {
		if (!valueset)
		    try {
		          wait();
	 	    }
		    catch (InterruptedException e) {
		          System.out.println("InterruptedException caught");
		    } 
		System.out.println( "Got: " + n);
		valueset = false;
		notify();
		return n;
	}
	
	synchronized void put(int n) {
		if (valueset)
		    try {
		          wait();
		    }
		    catch (InterruptedException e) {
		          System.out.println("InterruptedException caught");
		    } 
		this.n = n;
		valueset = true;
	    	System.out.println( "Put: " + n); 
		notify();
 	}
}