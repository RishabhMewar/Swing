package code;

public class Consumer1 implements Runnable {

	Q1 q;
	Consumer1 (Q1 q) {
		this.q = q;
	} 

	public void run( ) {
		while (true) {
			q.get();
		}
	}

}
