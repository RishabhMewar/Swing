package code;
public class Consumer implements Runnable {
	Q q;
	Consumer (Q q) {
		this.q = q;
	} 

	public void run() {
		int i = 1;
		while (i <= 20) {
			q.get();
			i++;
		}
	}
}