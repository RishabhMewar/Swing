package code;

public class Producer implements Runnable {
	Q q;
	Producer (Q q) {
		this.q = q;
	}
	
	public void run() {
		int i = 1; 
		while (i<=20) {
			q.put (i++); 
		}
	}	
}