package code;

public class TestRunnable {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		/*MultiThreadRunnable mtr1 = new MultiThreadRunnable();
		MultiThreadRunnable mtr2 = new MultiThreadRunnable();
		
		//New
		Thread t = new Thread(mtr1,"FirstThread");
		Thread t1 = new Thread(mtr2,"AnotherThread");
		
		// Set priority
		
		t.setPriority(Thread.MAX_PRIORITY);
		
		//Runnable
		t.start();
		t1.start();*/
		
		
		Thread t = new Thread(new MultiThread(),"First Thread");
		Thread t1 = new Thread(new MultiThread(),"AnotherThread");
		
		t.start();
		t1.start();
		
		
		for(int i = 1 ; i <= 10 ; i++){
			System.out.println("In " + Thread.currentThread().getName() + i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}