package code;

public class SyncThread implements Runnable {
	private TobeSync t;
	private volatile String s;

	public SyncThread(TobeSync t, String s) {
		super();
		this.t = t;
		this.s = s;
	}

	@Override
	public void run() {
		t.output(s);
	}
}