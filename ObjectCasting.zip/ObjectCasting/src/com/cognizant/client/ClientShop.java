package com.cognizant.client;

import com.cognizant.entity.Mall;
import com.cognizant.entity.Shop;

public class ClientShop {

	/**
	 * @param args
	 */
public static void main(String[] args) {
	//Upcasting is implicit. No casting required.
	Shop shop = new Mall(2, "xyz", 1000000, 20000, 5000);//Parent stores child reference
	shop.calculateProfit();//Calls the overridden method.
	System.out.println(shop);//Calls mall's toString
	
	Mall m = (Mall)shop;
	System.out.println(shop);//Calls mall's toString
	
	shop = new Shop(1, "abc", 100000, 2000);
	// m = (Shop)shop; Error not allowed.
	
	m = (Mall)shop;//ClassCastException.
	System.out.println(m);
}
}