package com.cognizant.entity;

public class Shop {
	private int registrationId;
	private String name;
	private float profit;
	private float tax;
	private float profitAfterTax;
	
	public Shop() {
		
	}
	
	public Shop(int registrationId, String name, float profit, float tax) {
		this.registrationId = registrationId;
		this.name = name;
		this.profit = profit;
		this.tax = tax;
	}

	public int getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getProfit() {
		return profit;
	}
	public void setProfit(float profit) {
		this.profit = profit;
	}
	public float getTax() {
		return tax;
	}
	public void setTax(float tax) {
		this.tax = tax;
	}
	public float getProfitAfterTax() {
		return profitAfterTax;
	}
	public void setProfitAfterTax(float profitAfterTax) {
		this.profitAfterTax = profitAfterTax;
	}
	
	public void calculateProfit(){
		this.profitAfterTax = this.profit - this.tax;
	}

	@Override
	public String toString() {
		return "Shop [registrationId=" + registrationId + ", name=" + name
				+ ", profit=" + profit + ", tax=" + tax + ", profitAfterTax="
				+ profitAfterTax + "]";
	}
	
}
