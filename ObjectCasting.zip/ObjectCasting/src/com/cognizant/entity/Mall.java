package com.cognizant.entity;

public class Mall extends Shop {
	private float importTax;

	public float getImportTax() {
		return importTax;
	}

	public void setImportTax(float importTax) {
		this.importTax = importTax;
	}

	public Mall(int registrationId, String name, float profit, float tax, float importTax) {
		super(registrationId, name, profit, tax);
		// TODO Auto-generated constructor stub
		this.importTax = importTax;
	}

	@Override
	public void calculateProfit() {
		// TODO Auto-generated method stub
		super.calculateProfit();
		float pat = getProfitAfterTax();
		setProfitAfterTax(pat-this.importTax);
	}

	@Override
	public String toString() {
		return "Registration Id: " + getRegistrationId()+"\n"+
				"Name: " + getName() + "\n"+
				"Profit: "+ getProfit() + "\n"+
				"Tax: "+getTax()+"\n"+
				"Import Tax: " + getImportTax() + "\n"+
				"Profit After Tax: " + getProfitAfterTax()+"\n"+
				"================================================";			
	}	
}