package com.capgemini.mobipur.bean;

public class MobileBean 
{
	//AutoGenerate 
	private int mobileId;
	private String name;
	private float price;
	private String quantity;
	
	//Default Constructor
	
	public MobileBean() 
	{
		super();
	}

	//Generate constructor (go to source then select constructor using fields then select all and deselect omit) 
	public MobileBean(int mobileId, String name, float price, String quantity) 
	{
		super();
		this.mobileId = mobileId;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}
	
	//Generate getters and setters (go to source then select getters and setters using fields then select all and deselect omit) 

	public int getMobileId() 
	{
		return mobileId;
	}

	public void setMobileId(int mobileId) 
	
	{
		this.mobileId = mobileId;
	}

	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}

	public float getPrice() 
	{
		return price;
	}

	public void setPrice(float price) 
	{
		this.price = price;
	}

	public String getQuantity() 
	{
		return quantity;
	}

	public void setQuantity(String quantity) 
	{
		this.quantity = quantity;
	}

	//Here we generate to string  (go to source then select tostring using fields do not select all and deselect omit) 

	@Override
	public String toString() 
	{
		return "MobileBean [mobileId=" + mobileId + ", name=" + name
				+ ", price=" + price + ", quantity=" + quantity + "]";
	}
	
	
	
	
	

}
