package com.capgemini.a1;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.Scanner;

public class ConvertDate {
	public static void main(String [] args){
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/mm/yyyy");
		
		Scanner scInput = new Scanner(System.in);
		
		String strDate = null;
		
		System.out.println("Enter Date: ");
		strDate = scInput.nextLine();
		
		TemporalAccessor ta = dtf.parse(strDate);
		
		LocalDate localDate = LocalDate.from(ta);
		
		java.sql.Date translateDate = java.sql.Date.valueOf(localDate);
		
		System.out.println(translateDate);
		
		scInput.close();
		
	}
}
