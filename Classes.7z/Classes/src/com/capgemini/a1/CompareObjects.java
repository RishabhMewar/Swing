package com.capgemini.a1;

public class CompareObjects 
{
	int a, b;
	CompareObjects(int i, int j) 
	{
		a = i;
		b = j;
	}
	// return true if o is equal to the invoking object
	boolean equals(CompareObjects o) 
	{
		if(o.a == a && o.b == b) 
			return true;
		else 
			return false;
	}
}
class PassOb 
{
	public static void main(String args[]) 
	{
		CompareObjects ob1 = new CompareObjects(100, 22);
		CompareObjects ob2 = new CompareObjects(100, 22);
		CompareObjects ob3 = new CompareObjects(-1, -1);
		System.out.println("ob1 == ob2: " + ob1.equals(ob2));
		System.out.println("ob1 == ob3: " + ob1.equals(ob3));
	}
}
