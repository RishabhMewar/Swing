package com.capgemini.a1;

public class Box6 {

}
