package com.capgemini.a1;

public class CallByReference 
{
	int a, b;
	CallByReference(int i, int j) 
	{
		a = i;
		b = j;
	}
	// pass an object
	void meth(CallByReference o) 
	{
		o.a *= 2;
		o.b /= 2;
	}
}
class CallByRef 
{
	public static void main(String args[]) 
	{
		CallByReference ob = new CallByReference(15, 20);
		System.out.println("ob.a and ob.b before call: " + ob.a + " " + ob.b);
		ob.meth(ob);
		System.out.println("ob.a and ob.b after call: " + ob.a + " " + ob.b);
	}
}
