package com.capgemini.a1;

public class ReturningObjects 
{
	int a;
	ReturningObjects(int i) 
	{
		a = i;
	}
	ReturningObjects incrByTen() 
	{
		ReturningObjects temp = new ReturningObjects(a+10);
		return temp;
	}
}
class RetOb 
{
	public static void main(String args[]) 
	{
		ReturningObjects ob1 = new ReturningObjects(2);
		ReturningObjects ob2;
		ob2 = ob1.incrByTen();
		System.out.println("ob1.a: " + ob1.a);
		System.out.println("ob2.a: " + ob2.a);
		ob2 = ob2.incrByTen();
		System.out.println("ob2.a after second increase: " + ob2.a);
	}
}

