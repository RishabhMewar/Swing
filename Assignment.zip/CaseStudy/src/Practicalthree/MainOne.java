package Practicalthree;

import java.util.Scanner;

public class MainOne {

	public static void main(String[] args) {
		
		Scanner scinput = new Scanner(System.in);
		StringBuilder strb= new StringBuilder("Vishal");
		
		strb.append(" Tandel");
	//	strb.append(" AAZZ");
		One obj = new One(strb);
		System.out.println("Enter your Choice");
		int choice = scinput.nextInt();
					 scinput.nextLine();
		
		
		switch(choice)
		{
			case 1:
				System.out.println("First condition: "+ strb);
				break;
			case 2:	
				String str= obj.replace();
				System.out.println("Second condition: "+ str);
				break;
			case 3:
				StringBuilder strb1=obj.upper();
				System.out.println("Third condition: "+ strb1);
				break;
			case 4:
				String s2=obj.dup();
				System.out.println("Fourth condition: "+ s2);
				break;
			default:
				System.out.println("Enter correct choice");
		
		}
		scinput.close();
	}

}
