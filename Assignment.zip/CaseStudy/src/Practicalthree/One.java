package Practicalthree;
import java.lang.StringBuilder;
public class One 
{
	
	public StringBuilder strb; 
	public String str ="Second String";
	public String str1 = "helloworld";
	public StringBuilder strb1 = new StringBuilder();
	public String s1= "asdfsa";
	public String s2="";
	
	
	public One(StringBuilder strb) {
		
		this.strb = strb;
	}

	public String replace()
	{
		for(int i=0;i<str.length();i++)
		{
			if(i%2!=0)
			{
				str= str.substring(0,i-1) + "#" + str.substring(i,str.length());
			}
		}
		return str;
	}

	public StringBuilder upper()
	{
		char ch;
		for(int i=0;i<str1.length();i++)
		{
			ch = str1.charAt(i);
			if(i%2==0)
			{
				strb1.append(String.valueOf(ch).toUpperCase());
			}
			else
			{
				strb1.append(String.valueOf(ch).toLowerCase());
			}
	
		}
		return strb1;
	}
	
	
	public String dup()
	{
		for(int i=0;i<s1.length();i++)
		{
			
				if(!s2.contains(String.valueOf(s1.charAt(i))))
				{
						s2+=(String.valueOf(s1.charAt(i)));
				}
			}
		return s2;
	}
		

	
	/*public void display()
	{
		System.out.println("First condition: "+strb);
		System.out.println("Second condition: "+str);
		System.out.println("Third condition: "+s2);
		System.out.println("Forth condition: "+strb1);
	}*/
}
