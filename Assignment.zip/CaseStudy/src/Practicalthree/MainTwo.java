package Practicalthree;

import java.util.Scanner;

public class MainTwo {

	public static void main(String[] args) {
		
		String s =new String();
		Scanner scinput = new Scanner(System.in);
		
		int flag=0;
		
		System.out.println("Enter the string: ");
		s= scinput.nextLine();
		for(int i=0;i<s.length()-1;i++)
		{
			if(!(s.charAt(i) < s.charAt(i+1)))
			{
				flag=1;
				break;
			}
		}	
		if(flag==0)
		{
			System.out.println("Postive String");
		}
		else
		{
			System.out.println("Negative String");
		}
		scinput.close();
	}

}
