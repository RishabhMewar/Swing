package Practicaltwo;

import java.util.Scanner;

public class MainTwo {

	public static void main(String[] args) {
		
		Two obj = new Two();
		Scanner scannerv = new Scanner(System.in); 
		System.out.println("Enter Number: ");
		int num = scannerv.nextInt();
				scannerv.nextLine();
		
		obj= new Two(num);
		obj.display();
	}

}
