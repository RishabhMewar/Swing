package Practicaltwo;

public enum Gender {

	M,F
}
