package Practicaltwo;

public class Two {

		int num;
		
		public Two() {
			
		}
		
		public Two(int num) {
			this.num = num;
		}

	/*	public int getNum() {
			return num;
		}



		public void setNum(int num) {
			this.num = num;
		}*/

		public void display()
		{
			if(num<0)
			{
				System.out.println("Number entered is Negative");
			}
			else
			{
				System.out.println("Number entered is Positive");
			}
		}
		

}

	


