package Practicaltwo;

public class MainFirst {

	public static void main(String[] args) {
		
		First obj= new First();
		obj= new First("Vishal","Tandel",'M',21,65.00f);
		obj.display();
		
	}

}
