package com.capgemini.cab.service;

import java.util.List;

import com.capgemini.cab.bean.MobileBean;
import com.capgemini.cab.dao.ICustomerDAO;
import com.capgemini.cab.dao.IPurchaseDetailsDAO;
import com.capgemini.cab.dao.MobileDAOImpl;
import com.capgemini.cab.dao.PurchaseDetailsDAOImpl;
import com.capgemini.cab.exception.CabException;

public class ServiceMobileImpl implements IServiceMobile {
	private ICustomerDAO mobileDAO;
	
	public ServiceMobileImpl() {
		mobileDAO = new MobileDAOImpl();
	}
	
	@Override
	public List<MobileBean> viewAll() throws CabException {
		List<MobileBean> mobileList = mobileDAO.viewAll();
		return mobileList;
	}

	@Override
	public boolean deleteMobile(int mobileId) throws CabException {
		IPurchaseDetailsDAO purchaseDetailsDAO = new PurchaseDetailsDAOImpl();
		boolean isPurchaseDeleted = purchaseDetailsDAO.deletePurchaseDetails(mobileId);
		boolean isDeleted = mobileDAO.deleteMobile(mobileId);
		return (isDeleted && isPurchaseDeleted);
	}

	@Override
	public List<MobileBean> search(float minPrice, float maxPrice)throws CabException {
	List<MobileBean> mobileList = mobileDAO.search(minPrice, maxPrice);
		return mobileList;
	}

}
