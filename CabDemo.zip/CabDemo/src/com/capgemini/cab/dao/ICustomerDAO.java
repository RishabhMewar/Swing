package com.capgemini.cab.dao;

import com.capgemini.cab.bean.CustomerBean;
import com.capgemini.cab.exception.CabException;

public interface ICustomerDAO {
	public boolean insertCustomer(final CustomerBean customerBean) throws CabException;
	
	public int viewCabs(String pin)throws CabException;
	
	public int getID() throws CabException;
}
