package com.bvk.client;

public class Client6 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int empid = 6;
		
		Dao dao = new Dao();
		
		dao.returnSalary(empid);
	}
}