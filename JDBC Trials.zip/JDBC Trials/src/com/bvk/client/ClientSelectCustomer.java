package com.bvk.client;

import java.util.ArrayList;
import java.util.List;

import com.bvk.dao.CustomerDAO;
import com.bvk.dao.CustomerDAOImpl;
import com.bvk.entity.CustomerTO;

public class ClientSelectCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<CustomerTO>listCustomers = new ArrayList<CustomerTO>();
		
		CustomerDAO customerDAO = new CustomerDAOImpl();
		
		listCustomers = customerDAO.viewCustomer();
		
		for (CustomerTO customerTO : listCustomers) {
			System.out.println(customerTO);
		}
	}
}