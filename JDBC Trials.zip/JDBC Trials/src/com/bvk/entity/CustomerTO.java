package com.bvk.entity;

public class CustomerTO {
	private int custId;
	private String name;
	private String address;
	
	public CustomerTO() {
		super();
	}

	public CustomerTO(int custId, String name, String address) {
		super();
		this.custId = custId;
		this.name = name;
		this.address = address;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "customerId: " + custId + "\n" +
			   "Name: " + name + "\n" +
			   "Address=" + address + "\n" +
			   "===============================================\n";
	}
}
