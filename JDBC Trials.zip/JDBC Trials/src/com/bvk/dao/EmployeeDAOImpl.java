package com.bvk.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import com.bvk.entity.EmployeeTO;
import com.bvk.helper.DBUtil;

public class EmployeeDAOImpl implements EmployeeDAO {

	@Override
	public int insertUsingProcedure(EmployeeTO employeeTO) {
		// TODO Auto-generated method stub
		int status = 0;
		
		Connection conn = null;
		CallableStatement cst = null;

		int empid = employeeTO.getEmpid();
		String name = employeeTO.getName();
		float salary = employeeTO.getSalary();
		
		conn = DBUtil.createConnection();
		try{
		cst = conn.prepareCall("{call insertemp(?,?,?)}");
		
		cst.setInt(1, empid);
		cst.setString(2, name);
		cst.setFloat(3, salary);

		boolean result = cst.execute();
		
		if (!result) {
			status = 1;
		} else {
			status = 0;
		}
		
		}catch (SQLException se) {
			System.out.println("Couldn't connect: " + se.getMessage());
			se.printStackTrace();
		} finally {
		DBUtil.closeConnection();
		}
		return status;
	}

	@Override
	public float getSalary(int empid) {
		// TODO Auto-generated method stub
		String query = new String("{CALL getemp(?,?)}");
		float salary= 0;
		
		Connection conn = null;
		CallableStatement cst = null;

		conn = DBUtil.createConnection();
		try{
		cst = conn.prepareCall(query);
		
		cst.setInt(1, empid);
		cst.registerOutParameter(2, Types.FLOAT);

		boolean result = cst.execute();
		
		if (!result) {
			salary = cst.getFloat(2);
		}		
		}catch (SQLException se) {
			System.out.println("Couldn't connect: " + se.getMessage());
			se.printStackTrace();
		} finally {
		DBUtil.closeConnection();
		}
		return salary;
	}

	@Override
	public float getSalaryByFunction(int empid) {
		// TODO Auto-generated method stub
		String query = new String("{CALL ? := getsal(?)}");
		float salary= 0;
		
		Connection conn = null;
		CallableStatement cst = null;

		conn = DBUtil.createConnection();
		try{
		cst = conn.prepareCall(query);
		
		cst.registerOutParameter(1, Types.FLOAT);
		cst.setInt(2, empid);

		boolean result = cst.execute();
		
		if (!result) {
			salary = cst.getFloat(1);
		}		
		}catch (SQLException se) {
			System.out.println("Couldn't connect: " + se.getMessage());
			se.printStackTrace();
		} finally {
		DBUtil.closeConnection();
		}
		return salary;
	}
}