package com.bvk.dao;

import java.util.List;

import com.bvk.entity.CustomerTO;

public interface CustomerDAO {
	int insertCustomer(CustomerTO customer);
	int updateCustomer(CustomerTO customer);
	int deleteCustomer(CustomerTO customer);
	List<CustomerTO>viewCustomer();
	
}
