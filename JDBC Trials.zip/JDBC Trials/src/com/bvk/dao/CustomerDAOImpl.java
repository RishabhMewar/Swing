package com.bvk.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bvk.entity.CustomerTO;
import com.bvk.helper.DBUtil;

public class CustomerDAOImpl implements CustomerDAO {

	@Override
	public int insertCustomer(CustomerTO customer) {
		// TODO Auto-generated method stub
		Connection connCustomer = null;
		PreparedStatement pstCustomer = null;
		/*Statement stCustomer = null;
		
		int custId = customer.getCustId();
		String name = customer.getName();
		String address = customer.getAddress();
		
		String sql = "INSERT INTO customer VALUES("+custId + ",'"+ name +"','"
				     + address+"')";*/
		String sql = "INSERT INTO customer VALUES(?,?,?)";
		
		int custId = customer.getCustId();
		String name = customer.getName();
		String address = customer.getAddress();
		
		int status = 0;
		
		connCustomer = DBUtil.createConnection();
		
		try{
			//stCustomer = connCustomer.createStatement();
			pstCustomer = connCustomer.prepareStatement(sql);
			pstCustomer.setInt(1, custId);
			pstCustomer.setString(2, name);
			pstCustomer.setString(3, address);
			
			//status = stCustomer.executeUpdate(sql);
			status = pstCustomer.executeUpdate();
			//DDL, DML statements. insert, update, delete, create, alter, truncate
		}catch(SQLException se){
			System.out.println("Problem with database. " + se.getMessage());
		}finally{
			DBUtil.closeConnection();
		}
		return status;
	}

	@Override
	public int updateCustomer(CustomerTO customer) {
		// TODO Auto-generated method stub
		Connection connCustomer = null;
		PreparedStatement pstCustomer = null;
		
		String sql = "UPDATE customer SET customerid=?, name=?,address=?" +
					 " WHERE customerid=?";
		
		int custId = customer.getCustId();
		String name = customer.getName();
		String address = customer.getAddress();
		
		int status = 0;
		
		connCustomer = DBUtil.createConnection();
		
		try{
			pstCustomer = connCustomer.prepareStatement(sql);
			pstCustomer.setInt(1, custId);
			pstCustomer.setString(2, name);
			pstCustomer.setString(3, address);
			pstCustomer.setInt(4, custId);
			
			//status = stCustomer.executeUpdate(sql);
			status = pstCustomer.executeUpdate();
			//DDL, DML statements. insert, update, delete, create, alter, truncate
		}catch(SQLException se){
			System.out.println("Problem with database. " + se.getMessage());
		}finally{
			DBUtil.closeConnection();
		}
		return status;
	}

	@Override
	public int deleteCustomer(CustomerTO customer) {
		// TODO Auto-generated method stub
		Connection connCustomer = null;
		PreparedStatement pstCustomer = null;
		
		String sql = "DELETE FROM customer WHERE customerid=?";
		
		int custId = customer.getCustId();
				
		int status = 0;
		
		connCustomer = DBUtil.createConnection();
		
		try{
			pstCustomer = connCustomer.prepareStatement(sql);
			pstCustomer.setInt(1, custId);
			
			//status = stCustomer.executeUpdate(sql);
			status = pstCustomer.executeUpdate();
			//DDL, DML statements. insert, update, delete, create, alter, truncate
		}catch(SQLException se){
			System.out.println("Problem with database. " + se.getMessage());
		}finally{
			DBUtil.closeConnection();
		}
		return status;
	}

	@Override
	public List<CustomerTO> viewCustomer() {
		// TODO Auto-generated method stub
		List<CustomerTO>listCustomers = new ArrayList<CustomerTO>();
		
		CustomerTO customerTO = null;
		
		int custId = 0;
		String name = null;
		String address = null;
		
		Connection connCustomer = null;
		PreparedStatement pstCustomer = null;
		ResultSet rsCustomer = null;
		
		String sql = "SELECT customerId, name, address FROM customer";
		
		connCustomer = DBUtil.createConnection();
		
		try{
			pstCustomer = connCustomer.prepareStatement(sql);
			rsCustomer = pstCustomer.executeQuery();
			
			while(rsCustomer.next()){
				custId = rsCustomer.getInt("customerId");
				name = rsCustomer.getString("name");
				address = rsCustomer.getString("address");
				
				customerTO = new CustomerTO(custId, name, address);
				
				listCustomers.add(customerTO);
			}
			//DDL, DML statements. insert, update, delete, create, alter, truncate
		}catch(SQLException se){
			System.out.println("Problem with database. " + se.getMessage());
		}finally{
			DBUtil.closeConnection();
		}
		return listCustomers;
	}
}