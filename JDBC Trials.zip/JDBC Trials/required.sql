CREATE TABLE emp1(
  empid INT PRIMARY KEY,
  name VARCHAR2(45) NOT NULL,
  salary FLOAT NOT NULL);
  
CREATE OR REPLACE PROCEDURE getemp(p_empid INT, p_amt OUT FLOAT)
IS
  BEGIN
    SELECT salary INTO p_amt FROM emp1 WHERE empid = p_empid;
END getemp;

CREATE OR REPLACE FUNCTION getsal(p_empid INT)
RETURN FLOAT
IS
v_salary FLOAT;
BEGIN
      SELECT salary INTO v_salary FROM emp1 WHERE empid = p_empid;
      RETURN v_salary;
END getsal;