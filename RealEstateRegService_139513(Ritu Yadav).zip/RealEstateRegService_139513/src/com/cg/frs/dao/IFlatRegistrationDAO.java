package com.cg.frs.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.frs.dto.FLatRegistrationDTO;
import com.cg.frs.exception.FlatRegServiceException;

//creating interface IFlatRegistrationDAO
public interface IFlatRegistrationDAO {

	// These are the two methods to be implemented
	int registerFlat(FLatRegistrationDTO flat) throws IOException,
			SQLException, FlatRegServiceException;

	ArrayList<Integer> getAllOwnerIds() throws IOException, SQLException,
			FlatRegServiceException;

}
