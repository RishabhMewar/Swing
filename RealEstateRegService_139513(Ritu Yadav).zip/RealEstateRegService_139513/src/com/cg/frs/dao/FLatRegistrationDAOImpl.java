package com.cg.frs.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.frs.dbutil.dbUtil;
import com.cg.frs.dto.FLatRegistrationDTO;
import com.cg.frs.exception.FlatRegServiceException;

//This class implements the IFlatRegistrationDAO interface
public class FLatRegistrationDAOImpl implements IFlatRegistrationDAO {
	Logger logger = Logger.getRootLogger();

	// This to configure the log4j.properties
	public FLatRegistrationDAOImpl() {
		PropertyConfigurator.configure("log4j.properties");
	}

	// This is to implement the methods created in the interface
	@Override
	public int registerFlat(FLatRegistrationDTO flat)
			throws FlatRegServiceException, IOException, SQLException {

		Connection con = null;// creation of connection
		int res = 0;
		int status = 0;
		con = dbUtil.getConnection();
		System.out.println("connection created");
		PreparedStatement ps = con
				.prepareStatement("INSERT INTO Flat_Registration values(flat_seq.nextval,?,?,?,?,?)");
		// retrieving values from the flat_registration tables
		ps.setInt(1, flat.getOwnerIdNo());
		ps.setInt(2, flat.getFlatType());
		ps.setInt(3, flat.getFlatArea());
		ps.setInt(4, flat.getRentAmount());
		ps.setInt(5, flat.getDepositAmount());
		status = ps.executeUpdate();
		// checking if the row has been inserted or not
		if (status == 0) {
			logger.error("insertion failed");

		} else {
			logger.info("insertion done");

		}
		// this is to fetch flat registration id from the flat_owners table
		Statement st = con.createStatement();
		ResultSet rs = st // to store the details in the result set object
				.executeQuery("select flat_seq.currval from Flat_Registration");
		while (rs.next()) {
			res = rs.getInt(1);
		}
		System.out.println("Flat successfully registered. Registration id:<"
				+ res + ">");

		return status;
	}

	// this is to get all the owner ids inserted in the the table through
	// arraylist
	@Override
	public ArrayList<Integer> getAllOwnerIds() throws IOException,
			SQLException, FlatRegServiceException {

		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(1);
		list.add(2);
		list.add(3);
		return list;
	}

}
