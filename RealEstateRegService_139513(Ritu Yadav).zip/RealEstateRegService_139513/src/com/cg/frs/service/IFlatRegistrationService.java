package com.cg.frs.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.frs.dto.FLatRegistrationDTO;
import com.cg.frs.exception.FlatRegServiceException;

//this is to create the interface
public interface IFlatRegistrationService {
	// methods to be implemented
	int registerFlat(FLatRegistrationDTO flat) throws IOException,
			SQLException, FlatRegServiceException;

	ArrayList<Integer> getAllOwnerIds() throws IOException, SQLException,
			FlatRegServiceException;

	boolean isValidDetails(FLatRegistrationDTO flatReg)
			throws FlatRegServiceException;

}
