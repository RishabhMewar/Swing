package com.cg.frs.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.frs.dao.FLatRegistrationDAOImpl;
import com.cg.frs.dao.IFlatRegistrationDAO;
import com.cg.frs.dto.FLatRegistrationDTO;
import com.cg.frs.exception.FlatRegServiceException;

public class FlatRegistrationServiceImpl implements IFlatRegistrationService {

	// dao object is created for dao class which is referencing dao
	// impplementation class
	// method is inserting the details of the flat in dao object
	IFlatRegistrationDAO dao = new FLatRegistrationDAOImpl();

	@Override
	public int registerFlat(FLatRegistrationDTO flat) throws IOException,
			SQLException, FlatRegServiceException {

		return dao.registerFlat(flat);
	}

	// this method is getting all the owner ids from the table
	@Override
	public ArrayList<Integer> getAllOwnerIds() throws IOException,
			SQLException, FlatRegServiceException {

		return dao.getAllOwnerIds();
	}

	// validation for ownerID
	public boolean validateOwnerIds(int ownerIds) {
		String oid = String.valueOf(ownerIds);
		if (oid.isEmpty())
			return false;
		Pattern ftPattern = Pattern.compile("[1-2]{1}");
		Matcher ftMatcher = ftPattern.matcher(oid);
		return ftMatcher.matches();

	}

	// validation for flat type
	public boolean validateFlatType(int flatType) {
		String ft = String.valueOf(flatType);
		if (ft.isEmpty())
			return false;
		Pattern ftPattern = Pattern.compile("[1-2]{1}");
		Matcher ftMatcher = ftPattern.matcher(ft);
		return ftMatcher.matches();
	}

	// validation for flat area
	public boolean validateFlatArea(int flatArea) {
		String fa = String.valueOf(flatArea);
		if (fa.isEmpty())
			return false;
		Pattern faPattern = Pattern.compile("[1-9]{1}[0-9]{2,5}");
		Matcher faMatcher = faPattern.matcher(fa);
		return faMatcher.matches();
	}

	// validation for rent amount
	public boolean validateRentAmount(int rentAmt) {
		String ra = String.valueOf(rentAmt);
		if (ra.isEmpty())
			return false;
		Pattern raPattern = Pattern.compile("[1-9]{1}[0-9]{2,8}");
		Matcher raMatcher = raPattern.matcher(ra);
		return raMatcher.matches();
	}

	// //validation for deposit amount
	public boolean validateDepositAmt(int depositAmt) {
		String da = String.valueOf(depositAmt);
		if (da.isEmpty())
			return false;
		Pattern daPattern = Pattern.compile("[1-9]{1}[0-9]{2,8}");
		Matcher daMatcher = daPattern.matcher(da);
		return daMatcher.matches();

	}

	// validations are being checked if they are being fulfilled or not
	@Override
	public boolean isValidDetails(FLatRegistrationDTO flatReg)
			throws FlatRegServiceException {
		List<String> validationErrors = new ArrayList<String>();
		boolean list = true;
		if (!(validateOwnerIds(flatReg.getOwnerIdNo()))) {
			if (flatReg.getOwnerIdNo() != 1 && flatReg.getOwnerIdNo() != 2
					&& flatReg.getOwnerIdNo() != 3) {
				validationErrors.add("\nOwner does not exist");
			}
		}
		if (!(validateFlatType(flatReg.getFlatType()))) {
			validationErrors.add("\nFlat type entered is incorrect");

		}
		if (!(validateFlatArea(flatReg.getFlatArea()))) {
			validationErrors.add("\nFlat Area entered is incorrect");
		}
		if (!(validateRentAmount(flatReg.getRentAmount()))) {
			validationErrors.add("\nRent amount is incorrect");
		}
		if (!(validateDepositAmt(flatReg.getDepositAmount()))) {
			if (flatReg.getDepositAmount() < flatReg.getRentAmount())
				validationErrors
						.add("Deposit amount cannot be less than Rent Amount");
		}
		if (!validationErrors.isEmpty()) {
			list = false;
			throw new FlatRegServiceException(validationErrors + "");// throws
																		// the
																		// exception
																		// in
																		// case
																		// of
																		// validation
																		// not
																		// being
																		// validated
		}

		return list;// return the list

	}

}
