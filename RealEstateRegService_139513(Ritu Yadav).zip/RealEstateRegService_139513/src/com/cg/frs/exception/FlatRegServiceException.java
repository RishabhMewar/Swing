package com.cg.frs.exception;

//serial id is generated
public class FlatRegServiceException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5431907879766460886L;

	// Excpetion class has been created
	public FlatRegServiceException(String message) {
		super(message);
	}

}
