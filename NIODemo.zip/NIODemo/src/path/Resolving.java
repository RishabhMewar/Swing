package path;
import java.nio.file.Path;
import java.nio.file.Paths;


public class Resolving {

	public static void main(String[] args) {
		Path p1 = Paths.get("C:\\poems");
		Path p2 = Paths.get("luci1.txt");
		
		System.out.println(p1.resolve(p2));
		
		Path p3 = Paths.get("C:\\text.txt");
		System.out.println(p3.resolve(p1));
		
		Path p4 = Paths.get("");
		System.out.println(p1.resolve(p4));
		
		Path p5 = Paths.get("poems\\Luci");
		System.out.println(p1.resolve(p5));
		Path p6 = Paths.get("luci4.txt");
		System.out.println(p5.resolve(p6));
	}
}