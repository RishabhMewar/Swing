package path;
import java.nio.file.Path;
import java.nio.file.Paths;


public class Normalizing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Path p1 = Paths.get("C:\\poems\\..\\\\poems\\luci1.txt");
		Path p1n = p1.normalize();// c:\poems\luci1.txt
		System.out.println(p1 + " normalized to " + p1n);
		
		Path p2 = Paths.get("C:\\poems\\luci1.txt");
		Path p2n = p2.normalize();
		System.out.println(p2 + " normalized to " + p2n);
		
		Path p3 = Paths.get("a\\..\\.\\test.txt");
		Path p3n = p3.normalize();
		System.out.println(p3 + " normalized to " + p3n);
	}
}