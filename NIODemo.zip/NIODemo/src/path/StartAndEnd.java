package path;
import java.nio.file.Path;
import java.nio.file.Paths;


public class StartAndEnd {

	public static void main(String[] args) {
		Path p1 = Paths.get("C:\\poems\\luci1.txt");
		Path p2 = Paths.get("LUCI1.txt");
		Path p3 = Paths.get("poems\\luci1.txt");
		Path p4 = Paths.get(".txt");
		
		boolean b1 = p1.endsWith(p2);
		System.out.println("If p1 ends with p2? " + b1);
		
		boolean b2 = p1.endsWith(p3);
		System.out.println("If p1 ends with p3? " + b2);
		
		boolean b3 = p1.endsWith(p4);
		System.out.println("If p1 ends with p4? " + b3);
		
		Path p5 = Paths.get("C:\\");
		Path p6 = Paths.get("C:\\poems");
		Path p7 = Paths.get("C:\\poem");
		
		boolean b4 = p1.startsWith(p5);
		System.out.println("If p1 starts with p5? " + b4);
		
		boolean b5 = p1.startsWith(p6);
		System.out.println("If p1 starts with p6? " + b5);
		
		boolean b6 = p1.startsWith(p7);
		System.out.println("If p1 starts with p7? " + b6);
	}
}