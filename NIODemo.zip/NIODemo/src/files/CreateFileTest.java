package files;

import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class CreateFileTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Path p1 = Paths.get("C:\\poems\\test.docx");

		try {
			Files.createFile(p1);
			System.out.println("File created: " + p1.toRealPath());
		} catch (FileAlreadyExistsException fae) {
			System.out.println("File already exists: " + fae.getMessage());
		} catch (NoSuchFileException nfe) {
			System.out.println("Folder for creating file, doesn't exists: " + nfe.getMessage());
		} catch (IOException ioe) {
			System.out.println(ioe.getMessage());
		}
	}
}