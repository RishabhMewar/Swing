package files;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class FileCopyTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Path source = Paths.get("C:\\poems\\luci1.txt");
		Path target = Paths.get("C:\\poems\\dir2\\luci1.txt");
		
		try{
			Path p = Files.copy(source, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
			System.out.println(source + " has been copied to " + p);
		}catch(IOException ioe){
			System.out.println(ioe.getMessage());
		}
	}
}