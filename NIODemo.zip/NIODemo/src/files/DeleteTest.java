package files;

import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class DeleteTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Path p1 = Paths.get("C:\\poems\\test.txt");
		Path p2 = Paths.get("c:\\onedirection\\songs");
		
		try{
			if(Files.exists(p1)){
				Files.delete(p1);
				System.out.println(p1 + " file deleted successfully");
			}else{
				System.out.println("test.txt file doesn't exist");
			}
			
			boolean wasDeleted = Files.deleteIfExists(p2);
			
			if(wasDeleted){
				System.out.println(p2 + " was removed successfully...");
			}else{
				System.out.println(p2 + " couldn't be removed");
			}
		}catch(FileAlreadyExistsException fae){
			System.out.println("File already exists: "+fae.getMessage());
		}catch(NoSuchFileException nfe){
			System.out.println(nfe.getMessage());
		}catch(IOException ioe){
			System.out.println(ioe.getMessage());
		}
	}
}