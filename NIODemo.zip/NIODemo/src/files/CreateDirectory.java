package files;

import java.io.File;

public class CreateDirectory {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file = new File("d:/mydirectory");
		File file1 = new File("d:/sample/important");
		try{
			file.mkdir();
			System.out.println("Directory created: " + file.toString());
			
			file1.mkdirs();
			System.out.println("Directory created: " + file1.toString());
		}catch(SecurityException ioe){
			System.out.println(ioe.getMessage());
		}
	}
}