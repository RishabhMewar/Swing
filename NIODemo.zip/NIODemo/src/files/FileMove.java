package files;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class FileMove {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Path source = Paths.get("C:\\poems\\luci1_backup.txt");
		Path target = Paths.get("C:\\poems\\dir2\\luci1_backup.txt");
		
		try{
			Path p = Files.move(source, target, StandardCopyOption.ATOMIC_MOVE);
			System.out.println(source + " has been moved to " + p);
		}catch(NoSuchFileException fae){
			System.out.println(fae.getMessage());
		}catch(IOException ioe){
			System.out.println(ioe.getMessage());
		}
	}
}