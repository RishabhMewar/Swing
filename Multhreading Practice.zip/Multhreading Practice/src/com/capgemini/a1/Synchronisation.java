package com.capgemini.a1;

public class Synchronisation 
{
	void call(String msg) 
	{
		System.out.print("[" + msg);
		try 
		{
			Thread.sleep(1000);
		} 
		catch(InterruptedException e) 
		{
			System.out.println("Interrupted");
		}
		System.out.println("]");
	}
}

class Callee implements Runnable 
{
		String msg;
		Callme target;
		Thread t;
		public Callee(Callme targ, String s) 
		{
			target = targ;
			msg = s;
			t = new Thread(this);
			t.start();
		}
		// synchronize calls to call()
		public void run() 
		{
			synchronized(target)
			{
				//synchronised block
				target.call(msg);
			}
		}
}
			
class Synch1
{
			public static void main(String args[]) 
			{
				Callme target = new Callme();
				Callee ob1 = new Callee(target, "Hello");
				Callee ob2 = new Callee(target, "Synchronized");
				Callee ob3 = new Callee(target, "World");
				// wait for threads to end
				try 
				{
					ob1.t.join();
					ob2.t.join();
					ob3.t.join();
				} 
				catch(InterruptedException e) 
				{
					System.out.println("Interrupted");
				}
			}

}
