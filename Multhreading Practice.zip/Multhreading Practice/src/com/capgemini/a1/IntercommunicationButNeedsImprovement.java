package com.capgemini.a1;

public class IntercommunicationButNeedsImprovement 
{
	int n;
	synchronized int get() 
	{
		System.out.println("Got: " + n);
		return n;
	}
	synchronized void put(int n) 
	{
		this.n = n;
		System.out.println("Put: " + n);
	}
}

class Producer implements Runnable 
{
	IntercommunicationButNeedsImprovement q;
	Producer(IntercommunicationButNeedsImprovement q) 
	{
		this.q = q;
		new Thread(this, "Producer").start();
	}
	public void run() 
	{
		int i = 0;
		while(true) 
		{
			q.put(i++);
		}
	}
}
class Consumer implements Runnable 
{
	IntercommunicationButNeedsImprovement q;
	Consumer(IntercommunicationButNeedsImprovement q) 
	{
		this.q = q;
		new Thread(this, "Consumer").start();
	}
	public void run() 
	{
		while(true) 
		{
			q.get();
		}
	}
}
class PC 
{
	public static void main(String args[]) 
	{
		IntercommunicationButNeedsImprovement q = new IntercommunicationButNeedsImprovement();
		new Producer(q);
		new Consumer(q);
		System.out.println("Press Control-C to stop.");
	}
}

