package com.capgemini.com.service;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.com.exception.MyException;

public class ServiceEmployeeImplTest {

	IServiceEmployee serviceEmployee;
	@Before
	public void setUp() throws Exception {
		
		serviceEmployee =new ServiceEmployeeImpl();
	}

	@After
	public void tearDown() throws Exception {
	
		serviceEmployee = null;
	}
	
	
	@Test /*(expected=IllegalArgumentException.class)*/
	public final void testUpdateMobile() {
		try{
			boolean isUpdated = serviceEmployee.updateMobile(45000,1021);
			assertTrue("No such mobile",isUpdated==true);
		}
		catch(MyException e)
		{
			e.printStackTrace();
		}
		
	}
	

}
