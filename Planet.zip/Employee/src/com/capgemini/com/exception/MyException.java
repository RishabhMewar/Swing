package com.capgemini.com.exception;

public class MyException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8060718434430549446L;

	public MyException()
	{
		super();
	}
	public MyException(String message)
	{
		super(message);
	}
}
