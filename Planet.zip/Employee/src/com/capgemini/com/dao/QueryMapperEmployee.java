package com.capgemini.com.dao;

public class QueryMapperEmployee {

	public static final String INSERT_PURCHASE= 
			"INSERT INTO employee VALUES(employee_sequence.NEXTVAL,?,?,?,?)";
	public static final String DELETE_PURCHASE=
			"DELETE FROM employee WHERE empname=?";
	
	public static final String VIEWALL_DETAILS=
			"SELECT empid,empname,hiredate,salary,designation FROM employee";
	
	public static final String UPDATE_MOBILES= 
			"UPDATE employee SET salary = ? WHERE empid=?";
	public static final String Employee_EmployeeId= 
			"select employee_sequence.CURRVAL from DUAL";
	
}
