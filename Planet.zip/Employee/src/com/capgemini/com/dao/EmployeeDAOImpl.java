package com.capgemini.com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.com.bean.Employee;
import com.capgemini.com.exception.MyException;
import com.capgemini.com.util.DBConnection;

public class EmployeeDAOImpl implements IEmployeeDAO {

	
	@Override
	public List<Employee> viewAll() throws MyException {
		
		List<Employee>employeeList = new ArrayList<Employee>();
		try(Connection connMobile = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=connMobile.prepareStatement(QueryMapperEmployee.VIEWALL_DETAILS);)
		{
			
			ResultSet rsemployees = preparedStatement.executeQuery();
			
			while(rsemployees.next())
			{
				Employee employee = new Employee();
				employee.setEmpid(rsemployees.getInt("empid"));
				employee.setEmpname(rsemployees.getString("empname"));
				employee.setHiredate(rsemployees.getString("hiredate"));
				employee.setSalary(rsemployees.getFloat("salary"));
				employee.setDesignation(rsemployees.getString("designation"));
				
				employeeList.add(employee);
			}
			if(employeeList.size() == 0)
			{	
				throw new MyException("No Records found");
			}	
		}catch(SQLException sqlEx)
		{
			throw new MyException(sqlEx.getMessage());
		}
	
		
		return employeeList;
	}

	@Override
	public boolean deleteMobile(String empname) throws MyException {
		
		int records =0;
		boolean isDeleted = false;
		
		try(Connection connPurchaseDetails = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=connPurchaseDetails.prepareStatement(QueryMapperEmployee.DELETE_PURCHASE);)
		{
			
		
			preparedStatement.setString(1,empname);
			
			
			records = preparedStatement.executeUpdate();
			
			if(records>0)
			{
				isDeleted = true;
			}
		}catch(SQLException sqlEx)
		{
			throw new MyException(sqlEx.getMessage());
		}
		
		return isDeleted;
	}

	@Override
	public String insertPurchase(Employee employee) throws MyException {
		 
		int records =0;
		boolean isInserted = false;
		ResultSet resultSet = null;
		String empId=null;
		try(Connection connPurchaseDetails = DBConnection.getInstance().getConnection();)
		{
			PreparedStatement preparedStatement=connPurchaseDetails.prepareStatement(QueryMapperEmployee.INSERT_PURCHASE);
		
			String strDate = employee.getHiredate();
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			TemporalAccessor ta = dtf.parse(strDate);
			LocalDate local = LocalDate.from(ta);
			java.sql.Date translatedDate = java.sql.Date.valueOf(local);
		
			preparedStatement.setString(1, employee.getEmpname());
			preparedStatement.setDate(2, translatedDate );
			preparedStatement.setFloat(3, employee.getSalary());
			preparedStatement.setString(4, employee.getDesignation());
			
			records = preparedStatement.executeUpdate();
			
			preparedStatement = connPurchaseDetails.prepareStatement(QueryMapperEmployee.Employee_EmployeeId);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				empId=resultSet.getString(1);
						
			}
	
			if(records==0)
			{
				throw new MyException("Inserting donor details failed ");

			}
			else
			{
				return empId;
			}
		}catch(SQLException sqlEx)
		{
			throw new MyException(sqlEx.getMessage());
		}
		
	}

	@Override
	public boolean updateMobile(float salary, int empid) throws MyException {

		int records =0;
		boolean isUpdated = false;
		
		try(Connection connMobile = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=connMobile.prepareStatement(QueryMapperEmployee.UPDATE_MOBILES);)
		{
		
			preparedStatement.setFloat(1, salary);
			preparedStatement.setInt(2,empid);
			
			
			records = preparedStatement.executeUpdate();
			if(records>0)
			{
				isUpdated = true;
			}
		}catch(SQLException sqlEx)
		{
			throw new MyException(sqlEx.getMessage());
		}
		
		return isUpdated;
		
	}

}
