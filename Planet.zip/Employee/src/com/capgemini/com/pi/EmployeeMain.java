package com.capgemini.com.pi;

import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.com.bean.Employee;
import com.capgemini.com.exception.MyException;
import com.capgemini.com.service.ServiceEmployeeImpl;


public class EmployeeMain {

	private static Logger logger = Logger.getRootLogger();
	public static void main(String[] args) {

			PropertyConfigurator.configure("resource/log4j.properties");
			boolean isinProcess = true;
			boolean isValid = false;
			byte choice=0;
			String employeeId=null;
			String empname = null;
			String hiredate = null;
			Float salary = (float) 0.0;
			String designation = null;
			
			Employee employee = null; 
			
			ServiceEmployeeImpl serviceemployeeimpl = new ServiceEmployeeImpl();
			
			List<Employee>employeeList =null;
			
			Scanner scInput = new Scanner(System.in);
			
			while(isinProcess)
			{
				System.out.println("1. Insert Employee Details.");
				System.out.println("2. View all details.");
				System.out.println("3. Delete Employee Details");
				System.out.println("4. Update Employee Salary.");
				System.out.println("0. Exit.");
				
				System.out.println("Enter the choice");
				choice = Byte.parseByte(scInput.nextLine());
				
				
			switch(choice)
				{
					case 1:
						
						while(!isValid)
						{	
							try
							{
								System.out.println("Enter the Employee name");
								empname = scInput.nextLine();
								isValid = serviceemployeeimpl.isValidName(empname);
							
							}catch(MyException mpe)	
							{
								logger.error("Invalid name: "+empname);
								System.err.println("Invalid name: "+empname);
								isValid = false;
							}
						}	
							isValid = false;
						
						
						
						while(!isValid)
						{
							try
							{
								System.out.println("Enter the Salary");
								 salary= scInput.nextFloat();
										 scInput.nextLine();
								isValid = serviceemployeeimpl.isValidSalary(salary);
								
							}catch(MyException mpe)	
							{
								logger.error("Invalid Salary: "+ salary);
								System.err.println("Invalid Salary: "+ salary);
								isValid = false;
							}
						}
							isValid = false;
					
					
						
						while(!isValid)
						{
								System.out.println("Enter the date");
	
								
								hiredate =scInput.nextLine();
								
								isValid = true;
							

						}
						isValid = false;
						
						while(!isValid)
						{
							try
							{
								System.out.println("Enter the Designation");
								designation = scInput.nextLine();
								isValid = serviceemployeeimpl.isValidDesignation(designation);
								
							}catch(MyException mpe)	
							{
								logger.error("Invalid Desination: "+designation);
								System.err.println("Invalid Designation: "+designation);
								isValid = false;
							}
						}
						
						employee= new Employee(empname,hiredate,salary,designation);
						try
						{
							employeeId=serviceemployeeimpl.insertPurchase(employee);
							
							if(employeeId!=null)
								System.out.println("Inserted Successfully! Employee Id: "+employeeId);
							
						}catch(MyException mpe)
						{
							logger.error(mpe.getMessage());
							System.err.println(mpe.getMessage());
						}
						break;
							
					case 2:		
						try{
							employeeList = serviceemployeeimpl.viewAll();
							for (Employee employee1 : employeeList) {
								System.out.println(employee1);
							}
							System.out.println("===============================================");
						}catch(MyException e)
						{
							logger.error(e.getMessage());
							System.err.println(e.getMessage());
						}
						break;
							
					case 3:		
						
						isValid = false;
						
						
						
							System.out.println("Enter employee name to be deleted");
							empname = scInput.nextLine();
						try{
							boolean isDeleted = serviceemployeeimpl.deleteMobile(empname);
							
							if(isDeleted)
							{
								System.out.println("Mobile record deleted Successfully");
							}
						}catch(MyException e)
						{
							logger.error(e.getMessage());
							System.err.println(e.getMessage());
						}
						
						break;
						
					case 4:		
						
						System.out.println("Enter the Salary to be update");
						salary = Float.parseFloat(scInput.nextLine());
						
						System.out.println("Enter the Employee id whose salary is to be updated");
						int	empid = scInput.nextInt();
						scInput.nextLine();
						
						try{
						
							
							serviceemployeeimpl.updateMobile(salary,empid);
						}catch(MyException e)
						{
							logger.error(e.getMessage());
							System.err.println(e.getMessage());
						}
						break;
						
					case 0:
						isinProcess = false;
						System.out.println("Exit");
						break;
						
					default:
						System.out.println("Invalid Input");
						logger.error("Invalid input" + choice);
						System.err.println("Invalid input" + choice);
						break;
				}
				
				
			}
			
			scInput.close();
		}		

			

	}


