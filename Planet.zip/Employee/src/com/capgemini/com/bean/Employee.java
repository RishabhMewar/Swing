package com.capgemini.com.bean;

public class Employee {
	private int empid;
	
	private String empname;
	private String hiredate;
	private float salary;
	private String designation;
	private String strdate;
	public Employee()
	{
		
	}
	public Employee(String empname,String hiredate, float salary, String designation) {
		super();
		this.empname = empname;
		this.hiredate = hiredate;
		this.salary = salary;
		this.designation = designation;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getHiredate() {
		return hiredate;
	}
	public void setHiredate(String hiredate) {
		this.hiredate = hiredate;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	
	
	public String getStrDate() {
		return strdate;
	}
	public void setStrDate(String strdate) {
		this.strdate = strdate;
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empname=" + empname
				+ ", hiredate=" + hiredate + ", salary=" + salary
				+ ", designation=" + designation + "]";
	}
	
	
	

}
