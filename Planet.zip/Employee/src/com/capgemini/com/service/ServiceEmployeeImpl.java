package com.capgemini.com.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.com.bean.Employee;
import com.capgemini.com.dao.IEmployeeDAO;
import com.capgemini.com.dao.EmployeeDAOImpl;
import com.capgemini.com.exception.MyException;


public class ServiceEmployeeImpl implements IServiceEmployee {


	private IEmployeeDAO employeeDAO;
	
	public ServiceEmployeeImpl()
	{
		employeeDAO = new EmployeeDAOImpl();
	}
	
	@Override
	public boolean updateMobile(float salary, int empid) throws MyException {
		IEmployeeDAO employeeDAO = new EmployeeDAOImpl();
		boolean isupdated= employeeDAO.updateMobile(salary,empid);
		
		return isupdated;
				
	}

	@Override
	public List<Employee> viewAll() throws MyException {

		List<Employee> employeeList = employeeDAO.viewAll();
		return employeeList;

	}

	@Override
	public boolean deleteMobile(String empname) throws MyException {

		IEmployeeDAO employeeDAO = new EmployeeDAOImpl();
		boolean isDeleted = employeeDAO.deleteMobile(empname);
		return (isDeleted);

	}

	@Override
	public String insertPurchase(Employee employee) throws MyException {

		IEmployeeDAO employeeDAO = new EmployeeDAOImpl();
		
		//ImobileDAO mobileDAO = new MobileDAOImpl();
		
		
		String empId = employeeDAO.insertPurchase(employee);
		
		
		return empId;	
		}
	
	public boolean isValidName(String empname) throws MyException
	{
		boolean isValid = false;
		String pattern = "[A-Z]{1}[A-Za-z]{1,19}";
		Pattern ptn = Pattern.compile(pattern);
		Matcher matcher = ptn.matcher(empname);
		isValid = matcher.matches();
		
		if(!isValid)
		{
			throw new MyException("Invalid Name");
		}
		return isValid;
	}
	
	public boolean isValidSalary(Float salary) throws MyException
	{
		boolean isValid = false;
		if(salary>0)
		{
			isValid = true;
		}
		return isValid;
	}
	
	public boolean isValidDesignation(String designation) throws MyException
	{
		boolean isValid = false;
		String pattern = "[A-Za-z]{1,50}";
		Pattern ptn = Pattern.compile(pattern);
		Matcher matcher = ptn.matcher(designation);
		isValid = matcher.matches();
		
		if(!isValid)
		{
			throw new MyException("Invalid Designation");
		}
		return isValid;
	}

}
