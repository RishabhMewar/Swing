package com.capgemini.com.service;

import java.util.List;

import com.capgemini.com.bean.Employee;
import com.capgemini.com.exception.MyException;

public interface IServiceEmployee {

	public boolean updateMobile(final float salary,final int empid)
			throws MyException;
		
		public List<Employee> viewAll() 
				throws MyException;
		
		public boolean deleteMobile(final String empname) 
				throws MyException;
	
		public String insertPurchase(final Employee employee)
				throws MyException;	
	
}
