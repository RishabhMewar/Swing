Create table employee (empid number(4),empname varchar2(30),hiredate date,salary number(8),designation varchar2(30));

insert into employee values(1004,'qwe','01/30/2012',20000,'software analyst');

insert into employee values(1005,'abc','11/15/2012',40000,'software analyst');

CREATE SEQUENCE employee_sequence
START WITH 1001;