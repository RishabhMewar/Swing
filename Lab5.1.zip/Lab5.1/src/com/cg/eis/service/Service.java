package com.cg.eis.service;

public class Service implements EmployeeService{
	
	
	public Service(){
		
	}
	
	public String schemeA()
	{
		System.out.println("Scheme A");
		String str1 = "schemeA";
		return str1;
	}
	
	public String schemeB()
	{
		System.out.println("Scheme B");
		String str2 = "schemeA";
		return str2;
	}
	
	public String schemeC()
	{
		System.out.println("Scheme C");
		String str3 = "schemeA";
		return str3;
	}

}
