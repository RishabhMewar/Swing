package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.Service;



public class ClientService {
	
	 
	
	
	
	
	public static void main(String[] args){
		double salary;
		int id;
		String name;
		//String designation;
		String insuranceScheme;
		Employee e = new Employee();
		
		Service s = new Service();
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the id: ");
		id = scan.nextInt();
				scan.nextLine();
		System.out.println("Enter the name: ");
		name = scan.nextLine();
		System.out.println("Enter Salary: ");
		salary = scan.nextDouble();
						scan.nextLine();
		/*System.out.println("Enter the Designation: ");
		String designation1 = scan.nextLine();*/
		e.setSalary(salary);
		e.setId(id);
		e.setName(name);
		
		
		if(salary > 5000 && salary < 20000 ){
			e.setDesignation("System Associate");
		 insuranceScheme = s.schemeA();
		}
		else if(salary >= 20000 && salary < 40000 ){
			e.setDesignation("Programmer");
			insuranceScheme = s.schemeB();
		}
		else if(salary >= 40000){
			e.setDesignation("Manager");
			insuranceScheme = s.schemeC();
		}
		else{
			e.setDesignation("Clerk");
			insuranceScheme = "No Scheme";
		}
		
		e.setInsuranceScheme(insuranceScheme);
		scan.close();
		
		/*System.out.println("EMP ID: "+ id);
		System.out.println("EMP Name: "+ name);
		System.out.println("EMP Salary: " +salary);
		e.desig();
		System.out.println("EMP Insurance Scheme: " +insuranceScheme);*/
		String str = e.toString();
		System.out.println(str);
	}
}