CREATE TABLE Employees (id NUMBER PRIMARY KEY, name VARCHAR2 (20), salary NUMBER(10,2));

INSERT INTO Employees VALUES(1001,'preet',30000.00);
INSERT INTO Employees VALUES(1002,'gunjan',38000.40);
INSERT INTO Employees VALUES(1003,'swag',15000.30);
//TO DO � INSERT few more mobile details.

