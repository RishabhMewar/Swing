package com.capgemini.employee.dao;

public class QueryMapperEmployees {

	public static final String INSERT_EMPLOYEES = 
			"INSERT INTO employee VALUES(?,?,TO_DATE('?','DD/MM/YYYY'),?,?,?)";
	
	public static final String DELETE_EMPLOYEES = 
			"DELETE FROM employee WHERE Employee_Code =?";
	
	public static final String VIEW_EMPLOYEES =
			"SELECT Employee_Code,Employee_Name,Salary FROM employee";
}

