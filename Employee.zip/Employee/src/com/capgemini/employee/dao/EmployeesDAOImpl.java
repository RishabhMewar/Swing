package com.capgemini.employee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.exception.EmployeesException;
import com.capgemini.employee.util.DBConnection;

public class EmployeesDAOImpl implements IEmployeeDAO {
	
	
	@Override
	public boolean insertEmployee(EmployeeBean employeeBean)
			throws EmployeesException {
		int records = 0;
		boolean isInserted = false;
		try(
				Connection connPurchaseDetails= DBConnection.getInstance().getConnection();	
				PreparedStatement preparedStatement=connPurchaseDetails.prepareStatement(QueryMapperEmployees.INSERT_EMPLOYEES);
			){
		
			
			
			preparedStatement.setInt(1, employeeBean.getEmployee_Code());
			preparedStatement.setString(2, employeeBean.getEmployee_Name());
			preparedStatement.setFloat(3, employeeBean.getSalary());
			
			records = preparedStatement.executeUpdate();
			
			if(records > 0){
				isInserted = true;
			}
		}
		
		catch(SQLException sqlEx){
			throw new EmployeesException(sqlEx.getMessage());
		}
			return isInserted;
		}
	

	@Override
	public boolean deleteEmployee(int Employee_Code) throws EmployeesException {
		int records = 0;
		boolean isDeleted = false;
		try(
				Connection connPurchaseDetails= DBConnection.getInstance().getConnection();	
				PreparedStatement preparedStatement=
					connPurchaseDetails.prepareStatement(QueryMapperEmployees.DELETE_EMPLOYEES);
			){
						
			preparedStatement.setInt(1,Employee_Code);
						
			records = preparedStatement.executeUpdate();
			
			if(records > 0){
				isDeleted  = true;
			}
		}
		
		catch(SQLException sqlEx){
			throw new EmployeesException(sqlEx.getMessage());
		}
		return isDeleted;
	}

	@Override
	public List<EmployeeBean> viewAll() throws EmployeesException {
			
		List<EmployeeBean>mobileList= new ArrayList<EmployeeBean>();
		
		try(
				Connection connMobile= DBConnection.getInstance().getConnection();	
				PreparedStatement preparedStatement=connMobile.prepareStatement(QueryMapperEmployees.VIEW_EMPLOYEES);
				ResultSet rsMobiles = preparedStatement.executeQuery();
				){
												
					while(rsMobiles.next()){
						EmployeeBean mobile = new EmployeeBean();
						
						mobile.setEmployee_Code(rsMobiles.getInt("Employee_Code"));
						mobile.setEmployee_Name(rsMobiles.getString("Employee_Name"));
						mobile.setSalary(rsMobiles.getFloat("Salary"));
					
						
						mobileList.add(mobile);
					}
					
					if(mobileList.size() == 0){
						throw new EmployeesException("No records found");
					}
		}
		catch(SQLException sqlEx){
			throw new EmployeesException(sqlEx.getMessage());
		}
			return mobileList;
	}
	

}
