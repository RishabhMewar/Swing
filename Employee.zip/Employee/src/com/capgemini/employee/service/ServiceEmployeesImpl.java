package com.capgemini.employee.service;

import java.util.List;

import com.capgemini.employee.bean.EmployeeBean;
import com.capgemini.employee.dao.EmployeesDAOImpl;
import com.capgemini.employee.dao.IEmployeeDAO;
import com.capgemini.employee.exception.EmployeesException;

public class ServiceEmployeesImpl implements IServiceEmployees {

	IEmployeeDAO employeeDAO = new EmployeesDAOImpl();
	
	@Override
	public boolean insertEmployees(EmployeeBean employeeBean)
			throws EmployeesException {
		
		boolean isItInserted = employeeDAO.insertEmployee(employeeBean);
		
		return isItInserted;
	}

	@Override
	public List<EmployeeBean> viewAll() throws EmployeesException {
		List<EmployeeBean> mobileList = employeeDAO.viewAll();
		return mobileList;
	}

	@Override
	public boolean deleteEmployee(int Employee_Code) throws EmployeesException {
		boolean isItDeleted = employeeDAO.deleteEmployee(Employee_Code);
		
		return isItDeleted;
	}

}
