package com.capgemini.employee.bean;


public class EmployeeBean {
	private int Employee_Code;
	private String Employee_Name;
	private float Salary;
	private char Grade;
	private int Department_Code;
	private String Date_Of_Joining;
	
	
	public EmployeeBean() {
		super();
	}


	public EmployeeBean(int employee_Code, String employee_Name, float salary,
			char grade, int department_Code, String date_Of_Joining) {
		super();
		Employee_Code = employee_Code;
		Employee_Name = employee_Name;
		Salary = salary;
		Grade = grade;
		Department_Code = department_Code;
		Date_Of_Joining = date_Of_Joining;
	}


	public int getEmployee_Code() {
		return Employee_Code;
	}


	public void setEmployee_Code(int employee_Code) {
		Employee_Code = employee_Code;
	}


	public String getEmployee_Name() {
		return Employee_Name;
	}


	public void setEmployee_Name(String employee_Name) {
		Employee_Name = employee_Name;
	}


	public float getSalary() {
		return Salary;
	}


	public void setSalary(float salary) {
		Salary = salary;
	}


	public char getGrade() {
		return Grade;
	}


	public void setGrade(char grade) {
		Grade = grade;
	}


	public int getDepartment_Code() {
		return Department_Code;
	}


	public void setDepartment_Code(int department_Code) {
		Department_Code = department_Code;
	}


	public String getDate_Of_Joining() {
		return Date_Of_Joining;
	}


	public void setDate_Of_Joining(String date_Of_Joining) {
		Date_Of_Joining = date_Of_Joining;
	}


	@Override
	public String toString() {
		return "EmployeeBean [Employee_Code=" + Employee_Code
				+ ", Employee_Name=" + Employee_Name + ", Salary=" + Salary
				+ ", Grade=" + Grade + ", Department_Code=" + Department_Code
				+ ", Date_Of_Joining=" + Date_Of_Joining + "]";
	}
	
}
