package com.me.client;
import java.util.ArrayList;
import java.util.Scanner;

public class ContainsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer>numbers = new ArrayList<Integer>();
				
		numbers.add(10);
		numbers.add(20);
		numbers.add(30);
		numbers.add(10);
		
		Scanner scInput = new Scanner(System.in);
		
		int n = 0;
		
		System.out.print("Enter elements to be searched: ");
		n = scInput.nextInt();
		
		if(numbers.contains(n)){
			System.out.println("Given number is present.");
		}else{
			System.out.println("Given number not present.");
		}
		
		scInput.close();
	}
}