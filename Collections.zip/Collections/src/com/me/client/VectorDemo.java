package com.me.client;

import java.util.Iterator;
import java.util.ListIterator;
import java.util.Vector;

public class VectorDemo {

	public static void main(String[] args) {
		Vector<Integer>numbers = new Vector<Integer>(3,4);
		
		System.out.println("Initial Capacity: " + numbers.capacity());
		
		numbers.add(10);
		numbers.add(20);
		numbers.add(30);
		numbers.add(40);
		
		System.out.println("Capacity after adding elements: " + numbers.capacity());
		
		System.out.println(numbers);
		
		int size = numbers.size();
		
		System.out.println("Using simple for loop:");
		for(int i = 0 ; i < size ; i++){
			System.out.println(numbers.get(i));
		}
		
		Iterator<Integer>itr = numbers.iterator();
		ListIterator<Integer>ltr = numbers.listIterator();
		
		System.out.println("Using Iterator:");
		
		while(itr.hasNext()){
			Integer number = itr.next();
			System.out.println(number);
			//itr.remove();
			//numbers.add(90); Adding elements while using iterator is not allowed.
		}
		
		System.out.println("Using List Iterator:");
		
		while(ltr.hasNext()){
			Integer number = ltr.next();
			System.out.println(number);
			ltr.add(40);//This is add method of List Iterator & not ArrayList. Hence, valid.
			//numbers.add(55);//Throws ConcurrentModificationException.
		}
		
		System.out.println("Using List Iterator in reverse order:");
		
		while(ltr.hasPrevious()){
			Integer number = ltr.previous();
			System.out.println(number);
		}
		
		System.out.println("Using for-each loop:");
		
		//Internally implements Iterator interface:
		for (Integer number : numbers) {
			System.out.println(number);
		}
	}
}