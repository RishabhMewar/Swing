package com.me.client;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class MapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer, Float>studRecords = new HashMap<Integer, Float>();
		
		Scanner scInput = new Scanner(System.in);
		
		int rollno = 0;
		float percent = 0.0f;
		
		while(true){
			System.out.print("Enter Roll no. Enter -999 to stop: ");
			rollno = scInput.nextInt();
				     scInput.nextLine();
			
		    if(rollno != -999){
			System.out.print("Enter Percentage: ");
			percent = scInput.nextFloat();
				  	  scInput.nextLine();
					  	  
			studRecords.put(rollno, percent);		    	
		    }else{
		    	break;
		    }
		}
		
		System.out.print("Enter Roll no. of the student, whose percentage is to be viewed: ");
		rollno = scInput.nextInt();
			     scInput.nextLine();
			     
		if(studRecords.containsKey(rollno)){
			percent = studRecords.get(rollno);
			
			System.out.println("Roll no. " + rollno + " has " + percent + " percent.");
		}else{
			System.out.println("Given rollno's record doesn't exist.");
		}
		scInput.close();
	}
}