package com.me.client;

import java.util.ArrayList;

public class ArrayListBulkMethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer>numbers = new ArrayList<Integer>();
		ArrayList<Integer>naturalNumbers = new ArrayList<Integer>();
		
		numbers.add(99);
		numbers.add(100);
		numbers.add(200);
		numbers.add(100);
		
		naturalNumbers.addAll(numbers);
		naturalNumbers.add(20);
		naturalNumbers.add(30);
		naturalNumbers.add(40);
		
		System.out.println("numbers:");
		System.out.println(numbers);
		
		System.out.println();
		
		System.out.println("natural numbers:");
		System.out.println(naturalNumbers);
		
		naturalNumbers.retainAll(numbers);
		
		System.out.println();
		System.out.println("natural numbers after retainAll:");
		System.out.println(naturalNumbers);
		
		naturalNumbers.add(20);
		naturalNumbers.add(30);
		naturalNumbers.add(40);
		
		System.out.println();
		System.out.println("natural numbers after adding:");
		System.out.println(naturalNumbers);
		
		naturalNumbers.removeAll(numbers);
		
		System.out.println();
		System.out.println("natural numbers after removeAll:");
		System.out.println(naturalNumbers);
	}
}