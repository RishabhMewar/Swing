package com.me.client;

import java.util.TreeSet;

public class WrapperTreeSetDemo {

	public static void main(String[] args) {
		TreeSet<Integer>sortedNumbers = new TreeSet<Integer>();
		
		sortedNumbers.add(90);
		sortedNumbers.add(2);
		sortedNumbers.add(33);
		sortedNumbers.add(15);
		sortedNumbers.add(25);
		sortedNumbers.add(87);
		sortedNumbers.add(56);
		
		for (Integer number : sortedNumbers) {
			System.out.println(number);
		}
	}
}