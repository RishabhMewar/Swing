package com.me.client;

import java.util.SortedSet;
import java.util.TreeSet;

public class SortedSetDemo {

	public static void main(String[] args) {
		SortedSet<String>strings = new TreeSet<String>();
		
		strings.add("Balaji");
		strings.add("Gayathri");
		strings.add("Bhalchandra");
		strings.add("Ameya");
		strings.add("Xavier");
		strings.add("Sukhbir");
		strings.add("Rahim");
		
		System.out.println(strings);
		
		SortedSet<String>newStrings = strings.headSet("Gayathri");
		System.out.println(newStrings);
		
		newStrings = strings.tailSet("Gayathri");
		System.out.println(newStrings);
		
		newStrings = strings.subSet("Ameya", "Rahim");
		System.out.println(newStrings);
		
		String str = strings.first();
		System.out.println(str);
	}
}