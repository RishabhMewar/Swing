package com.me.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CollectionsDemo {

	public static void main(String[] args) {
		List<Integer>numbers = new ArrayList<Integer>();
		
		numbers.add(99);
		numbers.add(100);
		numbers.add(200);
		numbers.add(100);
		
		Collections.sort(numbers);
		
		System.out.println(numbers);
		
		Collections.sort(numbers, Collections.reverseOrder());
		
		System.out.println(numbers);
		
		int index = Collections.binarySearch(numbers, 100);
		
		System.out.println(index);
		
		
	}
}