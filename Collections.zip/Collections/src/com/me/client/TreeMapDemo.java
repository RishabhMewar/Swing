package com.me.client;

import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

public class TreeMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer, Float>studRecords = new TreeMap<Integer, Float>();
		
		Scanner scInput = new Scanner(System.in);
		
		int rollno = 0;
		float percent = 0.0f;
		
		while(true){
			System.out.print("Enter Roll no. Enter -999 to stop: ");
			rollno = scInput.nextInt();
				     scInput.nextLine();
			
		    if(rollno != -999){
			System.out.print("Enter Percentage: ");
			percent = scInput.nextFloat();
				  	  scInput.nextLine();
					  	  
			studRecords.put(rollno, percent);		    	
		    }else{
		    	break;
		    }
		}
		
		Set<Integer>rollnos = studRecords.keySet();
		
		System.out.println("Rollno\tPercentage");
		
		for(Integer rno : rollnos){
			System.out.println(rno + "\t" + studRecords.get(rno));
		}
		scInput.close();
	}
}