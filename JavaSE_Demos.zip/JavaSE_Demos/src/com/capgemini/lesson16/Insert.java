package com.capgemini.lesson16;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class Insert {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try	{
			DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());
			Connection conn = 
			DriverManager.getConnection (
			"jdbc:oracle:thin:@localhost:1521:xe","RMEWAR","PARTHabha@20");

			
			Statement stmt = conn.createStatement (); 
			int count = stmt.executeUpdate ("insert into emp values(7888,'EhsaanFramosh','Team Lead',7839,TO_DATE('16/11/2017','DD/MM/YYYY'),1000,23,10)");
			
			
			System.out.println("Record is completely inserted !!");
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
		
	}

}
