package com.capgemini.lesson16;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class PreparedStat {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int eno=0;
        String ename=null;
        double esal=0.0;
        try{
        
        System.out.println("Enter the Employee Number := ");
        BufferedReader br1=new BufferedReader(new InputStreamReader(System.in));       
        eno=Integer.parseInt(br1.readLine());
        
        System.out.println("Enter the Employee Name := ");
        BufferedReader br2=new BufferedReader(new InputStreamReader(System.in));       
        ename=br2.readLine();
        
        System.out.println("Enter the Employee Salary := ");
        BufferedReader br3=new BufferedReader(new InputStreamReader(System.in));       
        esal=Double.parseDouble(br3.readLine());
        
        
               
        
        }catch(IOException e){ 
        	System.out.println(e.getMessage());
        }
        
        
		try	{
			DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());
			Connection conn = 
			DriverManager.getConnection (
			//Here we connect to our database table
			"jdbc:oracle:thin:@localhost:1521:xe", "rmewar", "PARTHabha@20");

			
			//Here we insert data into our database table in correct format
			PreparedStatement pstmt = conn.prepareStatement("insert into emp(empno,ename,sal) values(?,?,?)"); 
			//Next three statements are for getting input
			pstmt.setInt(1, eno);
			pstmt.setString(2,ename);
			pstmt.setDouble(3,esal);
			
			int count=pstmt.executeUpdate();
					
			System.out.println("Record is inserted successfully !!");
			
			pstmt.setInt(1, 1000);
			pstmt.setString(2,"Arvind");
			pstmt.setDouble(3,100000);
			
			count=pstmt.executeUpdate();
			
			System.out.println("Records affected: " + count);
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
	}

}
