package com.capgemini.lesson5.datetime;

import java.time.Instant;

public class InstantDemo {

	public static void main(String[] args) {
		Instant currentTime = Instant.now();
		
		System.out.println(currentTime);
	}
}