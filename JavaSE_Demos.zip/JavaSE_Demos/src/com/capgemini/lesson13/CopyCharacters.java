package com.capgemini.lesson13;

import java.io.FileReader;
import java.io.FileWriter;

public class CopyCharacters {
	public static void main(String[] args) {
		 
		try(FileReader inputStream = new FileReader("sampleinput.txt");
			FileWriter outputStream = new FileWriter("sampleoutput.txt");){
			
			int c;
			while ((c = inputStream.read()) != -1) {
				outputStream.write(c);
			}
			System.out.println("File written successfully...");
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
