import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Set;

public class ProperyDemo {

	public static void main(String[] args) {
		Properties properties = new Properties();
		
		FileInputStream oracleProps = null;
		
		try{
			oracleProps = new FileInputStream("oracle.properties");
			properties.load(oracleProps);
			
			String url = properties.getProperty("url");
			String username = properties.getProperty("username");
			String password = properties.getProperty("password");
			String driver = properties.getProperty("driver");
			
			System.out.println("url: " + url);
			System.out.println("username: " + username);
			System.out.println("password: " + password);
			System.out.println("driver: " + driver);
			
			System.out.println("Does user bvk exists? " + (properties.contains("bvk")));
			System.out.println("Does username key exists? " + (properties.containsKey("username")));
			System.out.println("Value for username: " + (properties.getProperty("username", "xyz")));
			System.out.println("No. of properties: " + properties.size());
			
			System.out.println("List of values: ");
			
			Enumeration<Object> values = properties.elements();
			
			while(values.hasMoreElements()){
				System.out.println(values.nextElement());
			}
			
			System.out.println("List of keys: ");
			
			Set<Object>keys = properties.keySet();
			
			for (Object key : keys) {
				System.out.println(key);
			}
			
			System.out.println("All properties printed:");
			
			properties.list(System.out);
		}catch(FileNotFoundException fnfe){
			System.out.println("Oracle.properties not found.");
		}catch(IOException fnfe){
			System.out.println("Oracle.properties not found.");
		}
	}
}