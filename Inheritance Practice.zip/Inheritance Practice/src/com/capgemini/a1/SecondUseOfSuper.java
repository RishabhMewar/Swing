package com.capgemini.a1;

public class SecondUseOfSuper 
{
	int i;
}
// Create a subclass by extending class A.
class D extends SecondUseOfSuper 
{
	int i; // this i hides the i in A
	D(int a, int b) 
	{
		super.i = a; // i in A
		i = b; // i in B
	}
	void show() 
	{
		System.out.println("i in superclass: " + super.i);
		System.out.println("i in subclass: " + i);
	}
}
class UseSuper 
{
	public static void main(String args[]) 
	{
		D subOb = new D(1, 2);
		subOb.show();
	}
}

