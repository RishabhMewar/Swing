package com.capgemini.a1;

public class OrderInWhichConstructorCalled 
{
	OrderInWhichConstructorCalled() 
	{
		System.out.println("Inside A's constructor.");
	}

}

//Create a subclass by extending class A.
class E extends OrderInWhichConstructorCalled 
{
	E() 
	{
		System.out.println("Inside B's constructor.");
	}
}
//Create another subclass by extending B.
class F extends E 
{
	F() 
	{
		System.out.println("Inside C's constructor.");
	}
}
class CallingCons 
{
	public static void main(String args[]) 		
	{
		E e = new E();
	}
}