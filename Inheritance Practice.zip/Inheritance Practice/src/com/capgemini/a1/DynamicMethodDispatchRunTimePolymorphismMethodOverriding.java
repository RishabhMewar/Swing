package com.capgemini.a1;

public class DynamicMethodDispatchRunTimePolymorphismMethodOverriding 
{
	void callme() 
	{
		System.out.println("Inside A's callme method");
	}
}
class J extends DynamicMethodDispatchRunTimePolymorphismMethodOverriding 
{
		// override callme()
		void callme() 
		{
			System.out.println("Inside B's callme method");
		}
}
class K extends DynamicMethodDispatchRunTimePolymorphismMethodOverriding 
{
		// override callme()
		void callme() 
		{
			System.out.println("Inside C's callme method");
		}
}
class Dispatch 
{
		public static void main(String args[]) 
		{
			DynamicMethodDispatchRunTimePolymorphismMethodOverriding a = new DynamicMethodDispatchRunTimePolymorphismMethodOverriding(); // object of type A
			J b = new J(); // object of type B
			K c = new K(); // object of type C
			DynamicMethodDispatchRunTimePolymorphismMethodOverriding r; // obtain a reference of type A
			r = a; // r refers to an DynamicMethodDispatchRunTimePolymorphismMethodOverriding object
			r.callme(); // calls DynamicMethodDispatchRunTimePolymorphismMethodOverriding's version of callme
			r = b; // r refers to a J object
			r.callme(); // calls J's version of callme
			r = c; // r refers to a K object
			r.callme(); // calls K's version of callme
		}
}
