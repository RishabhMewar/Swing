package com.capgemini.a1;

public class InheritanceForPrivateMembers 
{
	int i; // public by default
	private int j; // private to InheritanceForPrivateMembers
	
	void setij(int x, int y) 
	{
		i = x;
		j = y;
	}
}
// A's j is not accessible here.
class C extends InheritanceForPrivateMembers 
{
	int total;
	void sum() 
	{
		total = i + j; // ERROR, j is not accessible here
	}
}
class Access 
{
	public static void main(String args[]) 
	{
		C subOb = new C();
		subOb.setij(10, 12);
		subOb.sum();
		System.out.println("Total is " + subOb.total);
	}
}
