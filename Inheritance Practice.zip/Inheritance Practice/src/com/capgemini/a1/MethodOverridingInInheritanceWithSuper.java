package com.capgemini.a1;

public class MethodOverridingInInheritanceWithSuper 
{
	int i, j;
	MethodOverridingInInheritanceWithSuper (int a, int b) 
	{
		i = a;
		j = b;
	}
	// display i and j
	void show() 
	{
		System.out.println("i and j: " + i + " " + j);
	}
}

class H extends MethodOverridingInInheritanceWithSuper
{
	int k;
	H(int a, int b, int c) 
	{
		super(a, b);
		k = c;
	}
	// display k � this overrides show() in A
	void show() 
	{
		super.show(); // this calls MethodOverridingInInheritanceWithSuper's show()
		System.out.println("k: " + k);
	}
}
class Overriding 
{
	public static void main(String args[]) 
	{
		H subOb = new H(1, 2, 3);
		subOb.show(); // this calls show() in B
	}
}

