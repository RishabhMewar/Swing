package com.capgemini.a1;

public class MethodOverridingInInheritance 
{
	int i, j;
	MethodOverridingInInheritance (int a, int b) 
	{
		i = a;
		j = b;
	}
	// display i and j
	void show() 
	{
		System.out.println("i and j: " + i + " " + j);
	}
}

class G extends MethodOverridingInInheritance
{
	int k;
	G(int a, int b, int c) 
	{
		super(a, b);
		k = c;
	}
	// display k � this overrides show() in A
	void show() 
	{
		System.out.println("k: " + k);
	}
}
class Override 
{
	public static void main(String args[]) 
	{
		G subOb = new G(1, 2, 3);
		subOb.show(); // this calls show() in B
	}
}
