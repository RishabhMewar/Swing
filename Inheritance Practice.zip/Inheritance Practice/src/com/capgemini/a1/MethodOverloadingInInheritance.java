package com.capgemini.a1;

public class MethodOverloadingInInheritance 
{

	int i, j;
	MethodOverloadingInInheritance(int a, int b) 
	{
		i = a;
		j = b;
	}
	// display i and j
	void show() 
	{
		System.out.println("i and j: " + i + " " + j);
	}
}
// Create a subclass by extending class A.
class I extends MethodOverloadingInInheritance 
{
	int k;
	I(int a, int b, int c) 
	{
		super(a, b);
		k = c;
	}
	// overload show()
	void show(String msg) 
	{
		System.out.println(msg + k);
	}
}

class Overloading 
{
	public static void main(String args[]) 
	{
		I subOb = new I(1, 2, 3);
		subOb.show("This is k: "); // this calls show() in B
		subOb.show(); // this calls show() in A
	}
}
