package com.capgemini.a1;

public class CreatingOwnExceptionClass extends Exception
{
	private int detail;
	CreatingOwnExceptionClass(int a) 
	{
		detail = a;
	}
	public String toString() 
	{
		return "MyException[" + detail + "]";
	}
}
class ExceptionDemo 
{
	static void compute(int a) throws CreatingOwnExceptionClass 
	{
		System.out.println("Called compute(" + a + ")");
		if(a > 10)
			throw new CreatingOwnExceptionClass(a);
		System.out.println("Normal exit");
	}
	public static void main(String args[]) 
	{
		try 
		{
			compute(1);
			compute(20);
		} 
		catch (CreatingOwnExceptionClass e) 
		{
			System.out.println("Caught " + e);
		}
	}
}
