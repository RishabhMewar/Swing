package com.capgemini.a1;

public class UncaughtException 
{
	static void subroutine() 
	{
		int d = 0;
		int a = 10 / d;
	}
	public static void main(String args[]) 
	{
		UncaughtException.subroutine();
	}
}


